"""Publish a reconciled overview without changing individual verified job records."""
import sys,json,fcntl,datetime,collections
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from persistence import MANIFEST,REGISTRY,DURABLE,_send,check
from atomic_io import json_file
def main():
 check()
 with open(DURABLE/'export.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);m=json.load(open(MANIFEST));r=json.load(open(REGISTRY));counts=collections.Counter('/'.join(k.split('/')[:2]) for k,v in m['jobs'].items() if v.get('verified') and v.get('persisted'));m['verified_persisted_seed_counts']=dict(counts);m['status']=sys.argv[1] if len(sys.argv)>1 else 'running';m['updated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();json_file(m,MANIFEST);_send(MANIFEST,r);print(dict(counts),flush=True)
if __name__=='__main__':main()

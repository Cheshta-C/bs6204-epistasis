# Collocating or Interacting? Deep Learning of Variant-Pair Epistasis

Corrected original BS6204 study, starting commit `404f8bbba83f3ecfa92f1de0d43d89385db1d0ee`.
Historical source/README are preserved in `historical/404f8bb/`; existing `results/` and notebooks
are historical, not newly nested-validation results.

## Scientific protocol

The primary target is epsilon = zAB - zA - zB. Normalize singles and doubles using each assay's
measured SINGLE-mutant mean and sample SD (ddof=1). This is conditional on measured singles
being available for a held-out protein. No double-mutant Huber reference is fitted for the
primary study. M0 remains untrained: predicted epsilon=0, predicted effect=zA+zB.

M1 retains the original frozen ESM-2 650M residue features (1,280), shared mutation-site MLP,
learned amino-acid embeddings and width 128. M2 retains the original input projection, two GCN
layers, width 128, symmetric normalized contact/sequence-neighbor/self edges and direct 3D
distance. The only pair-input correction replaces ordered zA,zB by zA+zB and |zA-zB|, retaining
head dimensions. Models predict residuals with MSE. No 64/96-width network or calibrated M0
is introduced. Computational factoring in M1 and disconnected sparse batching in M2 preserve
network mathematics; prediction and gradient tests compare them against standard execution.

Primary cohort: 221,340 pairs, 47 assays, 45 proteins, with A4_HUMAN explicitly excluded.
All M1/M2 training/evaluation rows and splits match within a protocol. The full 235,355-pair
sequence set remains separate. The matched CSV reproduces the previously recorded SHA-256.

`configs/nested_v1.json` fixes five outer folds and three inner folds grouped by protein. The
separate robustness protocol groups both levels by 39 MMseqs2 similarity components. Clustering
uses 30% identity and 80% coverage, including a >=40-aa shorter-domain rule at E<=0.001.
All assay sequences are included before forming connected components; no representative-only
assignment can split one protein. This heuristic does not prove absence of remote homology.

Three fixed candidates: (Adam LR, dropout, weight decay) = (0.001,0,0),
(0.001,0.1,0.0001), (0.0003,0.3,0.001). Hidden widths stay fixed. Maximum 40 epochs, patience
five, minimum improvement 0.0001, no smoothing. Select macro-PROTEIN interaction Spearman,
concatenating all assays of a protein before calculating its statistic. Average ranks handle
ties. Undefined correlations are omitted with eligibility counts; no defined correlation fails
the candidate. Candidate ties within tolerance favor the earlier predefined candidate. Inner
folds are weighted by eligible protein count. Final epochs are the rounded median of the
selected candidate's three best inner epochs. Fresh final seeds: 0,1,2. Outer outcomes never
tune hyperparameters or stopping. Original batch sizes: M1 4,096; M2 2,048.

Primary metrics: interaction Spearman, strong-interaction AUROC (|epsilon|>1; score |prediction|),
interaction RMSE. Secondary: effect metrics, macro-assay, pooled, per-protein, per-seed,
geometry, threshold sensitivity 0.5/1.5. M0 Spearman is undefined. M0 AUROC is 0.5 only with
both classes. Paired 2,000-replicate percentile intervals resample whole proteins or whole
similarity components, retaining multiplicity. They condition on the saved OOF fits rather
than refitting the complete training procedure per bootstrap. Mean seed metrics are not an
averaged-prediction ensemble. Effect RMSE equals residual RMSE under the shared reconstruction.

## Persistence gate and exact order

The runtime used Python 3.12, CPU FP32, two Torch threads per fold worker and up to four
independent outer-fold workers. This changes scheduling, not records, batches or architectures.
Install CPU Torch from its official wheel index, then the exact versions in the dependency lock.

1. Restore the supplied configuration, original snapshot and verified input/embedding archives.
   Reuse valid complete artifacts. Public sources and checksums are in the input audit/manifests.
2. Run `python -m unittest discover -s tests -v`.
3. Set `BS6204_WORKSPACE` to the workspace containing `artifacts/`, `durable/`, and the current
   Library transfer helper directory. The supplied study used a connected ChatGPT Library;
   those helpers require that authenticated environment. Do not claim a temporary folder is
   durable or disable the gate silently for a resumed hosted run.
4. Run `python -u run_project.py`. Required priority order is M1 protein, M2 protein,
   M1 cluster, M2 cluster. Selected inner searches are exported before final fitting. Every
   completed seed saves its checkpoint immediately, then predictions, true labels, IDs,
   metrics and histories. Files are reopened, metrics recomputed, the checkpoint reloaded,
   and predictions independently checked using the standard original class execution.
5. Each seed's immutable verified ZIP and the updated progress manifest must receive successful
   persistent-destination acknowledgments BEFORE the next seed. Exports serialize through a
   process lock. Failure/uncertainty creates a stop marker and halts subsequent scientific work.
   On resume, skip only jobs whose actual files, hashes, signature, metrics and checkpoint
   inference pass verification and whose export is recorded as confirmed.
6. Each completed protocol/model package is exported immediately. The final verifier replays
   all 60 checkpoints, checks actual split separation and M1/M2 split equality, and recomputes
   every scientific table from saved OOF data, requiring byte-identical CSVs.

The canonical prepared input table matches recorded SHA-256
`4277f5a8631d0b4be22e431ff3bd02c3c4870c30a488b3af19f65a07ad9cb459`.
Normalization intervention, source replay and structure mapping audits precede any training.
The recorded earlier M1 means are provisional and never substituted for saved-prediction results.

Original no-singles code remains in the historical snapshot. Its assay-specific fitted output
reference does not establish zero-shot prediction. The corrected legacy flag is only an input
masking diagnostic; normalization, labels and effect reconstruction still need singles. It is
not included in primary tables. Optional structural ablations are flagged in the runner but
are not implied to be completed. No structural-utility conclusion follows from geometry alone.

The residual is an additive-scale statistical epistasis proxy, not a universal molecular
interaction energy. Historical fitted-reference scores and revised naive-target scores cannot
be compared numerically as though only model training changed.

## Restore the delivered packages

Use a workspace containing this checkout as `bs6204-epistasis/`. Extract the canonical input
archive at workspace root (it contains `artifacts/inputs` and `artifacts/clusters`). Extract
the final embedding archive into `artifacts/` (it contains `caches/`). The preprocessing audit
archive extracts at workspace root. Extract the recovered configuration at workspace root;
it contains `recovered_record/` and `verified/`. Each final model package extracts at workspace
root into `artifacts/runs/` and `artifacts/evaluation/`. Individual incremental seed/search
archives instead contain `runs/` and should be extracted into `artifacts/`.

Keep the latest progress manifest in `durable/BS6204_Progress_Manifest.json`. The manifest
records immutable seed-package hashes and confirmed remote identities. Transfer receipts and
current authentication are required for resumed hosted writes; never treat old package
existence as authority to overwrite a different remote version. To inspect existing results
without training, use `src/evaluate_results.py artifacts --protocol protein --models M1 M2
--out artifacts/evaluation/protein`, followed by the equivalent cluster command. Verification
requires the manifest and prepared caches; it replays actual model checkpoints.

`prepare_from_public.py` downloads exact-hash public raw sources. It refuses changed bytes,
including a changed public MMseqs2 binary. `--rebuild-inputs` reconstructs the original source
cohort and corrected normalized structural table; `--regenerate-embeddings` downloads the real
650M encoder and regenerates features only if a usable cache is absent. `src/prepare_audit.py`
checks the matched hash, normalization intervention and historical source replay, reruns
MMseqs2, and exports reusable inputs. Restore verified archives rather than repeating these
steps when valid copies exist. Public downloads and pretrained weights can require network
access and significant memory; no substitute encoder is used on failure.

After `src/verify_all.py artifacts` passes, `python make_final_outputs.py` creates the report,
scientific SVG/PDF/PNG figures, exact CSV figure sources and presentation speaker content.
These authoring scripts are separate from the source-hashed scientific training modules.

"""Publish the exact current source branch and fresh transfer helpers."""
import sys,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,archive,publish
def main():
 subprocess.run(['git','-C',str(ROOT),'bundle','create',str(DURABLE/'bs6204-corrected.bundle'),'--all'],check=True)
 (DURABLE/'bs6204-corrections.patch').write_bytes(subprocess.check_output(['git','-C',str(ROOT),'diff','404f8bbba83f3ecfa92f1de0d43d89385db1d0ee','HEAD']))
 names=subprocess.check_output(['git','-C',str(ROOT),'ls-files','-z']).decode().split('\0');files=[(ROOT/n,n) for n in names if n and (ROOT/n).is_file()]
 files += [(DURABLE/'bs6204-corrected.bundle','BS6204_Code_Branch.bundle'),(DURABLE/'bs6204-corrections.patch','BS6204_Corrections.patch')]
 files += [(BASE/'.persistent_export_v2'/n,'hosted_transfer_helpers/'+n) for n in ['library_upload.py','library_download.py','library_file_transfer.py','library_hosted_apps.py','run_upload_with_timeout.py']]
 archive(DURABLE/'BS6204_Revised_Code.zip',files);publish(DURABLE/'BS6204_Revised_Code.zip')
if __name__=='__main__':main()

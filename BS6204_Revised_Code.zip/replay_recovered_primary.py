"""Verify restored immutable primary artifacts and reconcile an acknowledged search."""
import sys,json,datetime
from pathlib import Path
import numpy as np,pandas as pd,torch
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,MANIFEST,REGISTRY,archive,publish
from atomic_io import sha,json_file,csv_file
from nested_runner import signature,verify_seed
from model_runtime import Features,group_folds
from evaluate_results import evaluate
def main():
 torch.set_num_threads(2);torch.set_num_interop_threads(1);w=BASE/'artifacts';out=w/'verification';out.mkdir(exist_ok=True);m=json.load(open(MANIFEST));audit=json.load(open(w/'audit/input_audit.json'))
 assert audit['cohort_verified'] and sha(w/'inputs/pairs_struct.csv')==audit['matched_sha256'] and sha(w/'caches/wt_emb_650.pt')==audit['cache_sha256'] and sha(w/'inputs/contacts.npz')==audit['contacts_sha256']
 d=pd.read_csv(w/'inputs/pairs_struct.csv').merge(pd.read_csv(w/'clusters/clusters.csv'),on='UniProt_ID',how='left',validate='many_to_one');assert (len(d),d.assay.nunique(),d.UniProt_ID.nunique())==(221340,47,45);d['pair_id']=d.assay+'::'+d.mutant;outer=group_folds(d,'UniProt_ID',5);d['outer_fold']=outer;rows=[]
 emb=torch.load(w/'caches/wt_emb_650.pt',map_location='cpu',weights_only=True);contacts=dict(np.load(w/'inputs/contacts.npz'))
 for model in ['M1','M2']:
  sig=signature(w,ROOT/'configs/nested_v1.json',model,'protein','full');features=Features(d,emb,contacts,model)
  for fold in range(5):
   fo=w/f'runs/durable_v2/protein/{model}/fold_{fold}';assert json.load(open(fo/'COMPLETE.json'))['signature']==sig
   inner=pd.read_csv(fo/'inner_assignments.csv');assert set(inner.UniProt_ID)==set(d[outer!=fold].UniProt_ID) and (inner.groupby('UniProt_ID').inner_fold.nunique()==1).all()
   for seed in [0,1,2]:
    key=f'protein/{model}/fold_{fold}/seed_{seed}';rec=m['jobs'][key];job=fo/f'seed_{seed}';assert rec['persisted'] and rec['verified'] and rec['signature']==sig;required=['checkpoint.pt','configuration.json','heldout_predictions.csv','metrics.json','per_protein.csv','per_assay.csv','training_history.csv'];assert all(n in rec['files'] and (job/n).is_file() and sha(job/n)==rec['files'][n] for n in required);assert all(n in required or n.endswith('.partial') for n in rec['files']);ck=torch.load(job/'checkpoint.pt',map_location='cpu',weights_only=True);assert set(ck['train_proteins'])==set(d[outer!=fold].UniProt_ID)
    result=verify_seed(job,features,np.flatnonzero(outer==fold),sig,fold,seed);rec['files']={n:result['files'][n] for n in required};result['files']=rec['files'];json_file(result,job/'verification.json');rows.append(dict(model=model,fold=fold,seed=seed,n_test=result['n_test'],max_abs_inference_difference=result['max_abs_inference_difference'],checkpoint_sha256=sha(job/'checkpoint.pt'),verified=True));print('RESTORED CHECKPOINT VERIFIED',key,flush=True)
  del features
 csv_file(pd.DataFrame(rows),out/'recovered_primary_checkpoint_replay.csv');replay=out/'recovered_protein_tables';evaluate(w,'protein',['M1','M2'],replay)
 for f in replay.glob('*.csv'):assert sha(f)==sha(w/'evaluation/protein'/f.name),f
 # This complete search reached Library before its manifest acknowledgment was lost.
 fo=w/'runs/durable_v2/cluster/M1/fold_2';proof=json.load(open(fo/'search_verification.json'));sig=signature(w,ROOT/'configs/nested_v1.json','M1','cluster','full');assert proof['signature']==sig and all((fo/n).is_file() and sha(fo/n)==s for n,s in proof['files'].items());assert len(pd.read_csv(fo/'candidates.csv'))==9
 p=DURABLE/'BS6204_Selection_cluster_M1_f2.zip';receipt={'library_file_id':'libfile_2b2bdfd46cbc8191a4e24efeb6bf8f9b','current_version_number':None,'sha256':sha(p),'bytes':p.stat().st_size,'url':'https://chatgpt.com/library?file_id=libfile_2b2bdfd46cbc8191a4e24efeb6bf8f9b&account_id=personal','download_and_search_content_verified':True};r=json.load(open(REGISTRY));r[p.name]=receipt;json_file(r,REGISTRY);m['artifacts'][p.name]=receipt;m['selections']['cluster/M1/fold_2']={'verified':True,'persisted':True,'artifact':receipt};m['status']='restored_primary_verified_resuming_cluster';m['updated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();m['verified_persisted_seed_counts']={'protein/M1':15,'protein/M2':15};m['recovery_file_list_note']='Completion records now list authoritative model outputs only; nonessential temporary-write entries were removed after checkpoint replay. Model and prediction bytes are unchanged.';json_file(m,MANIFEST)
 json_file({'restored_primary_checkpoints_verified':30,'all_221340_oof_pairs_per_seed':True,'primary_metrics_recomputed_csv_byte_identical':True,'reusable_cluster_searches':[1,2,3],'no_training_repeated':True,'embedding_cache_reused':True},out/'recovered_primary_verification.json');z=DURABLE/'BS6204_Recovery_Verification.zip';files=[(f,'artifacts/verification/'+str(f.relative_to(out))) for f in out.rglob('*') if f.is_file()];files += [(f,'artifacts/runs/durable_v2/cluster/M1/fold_2/'+f.name) for f in fo.iterdir() if f.is_file()];archive(z,files);publish(z);print('ALL 30 RESTORED PRIMARY CHECKPOINTS AND EXACT METRICS VERIFIED',flush=True)
if __name__=='__main__':main()

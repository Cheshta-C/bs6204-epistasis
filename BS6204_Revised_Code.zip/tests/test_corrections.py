import unittest,sys,tempfile,subprocess
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import numpy as np,pandas as pd,torch
from train_m1 import EpistasisHead
from train_m2 import M2,norm_adj
from model_runtime import Features,group_folds
from scientific_metrics import score,validate
from evaluate_results import paired_ci
from atomic_io import write

torch.set_num_threads(1)
class Corrections(unittest.TestCase):
 def data(self):return pd.DataFrame(dict(assay=['a','a','b','b'],UniProt_ID=['p','p','q','q'],pos_a=[1,2,3,1],pos_b=[3,4,2,4],wt_a=['A']*4,aa_a=['C']*4,wt_b=['D']*4,aa_b=['E']*4,z_a=[.1,.3,.5,.2],z_b=[-.3]*4,z_ab=[1.]*4,seq_distance=[2,2,1,3],dist_3d=[5.]*4))
 def test_m1_complete_mutation_swap(self):
  torch.manual_seed(0);net=EpistasisHead(1280,dropout=.3).eval();a,b=torch.randn(8,1280),torch.randn(8,1280);wa,ma,wb,mb=[torch.randint(0,20,(8,)) for _ in range(4)];za,zb,sd=[torch.randn(8) for _ in range(3)]
  torch.testing.assert_close(net(a,wa,ma,b,wb,mb,za,zb,sd),net(b,wb,mb,a,wa,ma,zb,za,sd),atol=1e-6,rtol=1e-6)
 def test_m2_complete_mutation_swap(self):
  torch.manual_seed(0);net=M2(1280,dropout=.3).eval();h=net.gnn(norm_adj(10,[(1,6)]),torch.randn(10,1280));a,b=torch.tensor([0,2,4]),torch.tensor([3,8,7]);wa,ma,wb,mb=[torch.randint(0,20,(3,)) for _ in range(4)];za,zb,d3,sd=[torch.randn(3) for _ in range(4)]
  scal=torch.stack([za+zb,abs(za-zb),d3,sd],-1);swap=torch.stack([zb+za,abs(zb-za),d3,sd],-1)
  torch.testing.assert_close(net.pair(h[a],wa,ma,h[b],wb,mb,scal),net.pair(h[b],wb,mb,h[a],wa,ma,swap),atol=1e-6,rtol=1e-6)
 def equivalence(self,name):
  torch.manual_seed(3);d=self.data();f=Features(d,{'a':torch.randn(4,1280),'b':torch.randn(5,1280)},{'a':np.array([[1,3]]),'b':np.array([[2,4],[1,5]])},name);net=EpistasisHead(1280,dropout=0) if name=='M1' else M2(1280,dropout=0);net.eval();idx=np.arange(4)
  if name=='M1':old=net(f.allX[f.ia],f.wta,f.muta,f.allX[f.ib],f.wtb,f.mutb,f.za,f.zb,f.sd)
  else:
   old=[]
   for i,r in enumerate(d.itertuples()):
    h=net.gnn(f.adj[r.assay],f.X[r.assay]);b=np.array([i]);sc=torch.stack([f.za[b]+f.zb[b],abs(f.za[b]-f.zb[b]),f.d3[b],f.sd[b]],-1);old.append(net.pair(h[f.ra[b]],f.wta[b],f.muta[b],h[f.rb[b]],f.wtb[b],f.mutb[b],sc))
   old=torch.cat(old)
  torch.testing.assert_close(old,f.forward(net,idx),atol=1e-6,rtol=1e-5);old.sum().backward();grads=[p.grad.clone() for p in net.parameters()];net.zero_grad();f.forward(net,idx).sum().backward()
  for g,p in zip(grads,net.parameters()):torch.testing.assert_close(g,p.grad,atol=3e-6,rtol=1e-4)
 def test_m1_factoring_predictions_and_gradients(self):self.equivalence('M1')
 def test_m2_sparse_predictions_and_gradients(self):self.equivalence('M2')
 def test_real_preprocessing_double_intervention(self):
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);raw=r/'raw';raw.mkdir();pd.DataFrame([dict(DMS_filename='toy.csv',UniProt_ID='P',target_seq='AC',coarse_selection_type='Stability')]).to_csv(r/'meta.csv',index=False)
   for i,double in enumerate([5.,1e12]):
    pd.DataFrame(dict(mutant=['A1C','C2D','A1C:C2D'],DMS_score=[1.,3.,double])).to_csv(raw/'toy.csv',index=False);subprocess.run([sys.executable,str(Path(__file__).resolve().parents[1]/'src/build_pairs.py'),str(raw),str(r/'meta.csv'),'--min-doubles','1','--out',str(r/f'out{i}')],check=True,stdout=subprocess.DEVNULL)
   a=pd.read_csv(r/'out0/assay_fits.csv');b=pd.read_csv(r/'out1/assay_fits.csv');np.testing.assert_allclose(a[['score_mean','score_sd']],b[['score_mean','score_sd']]);self.assertEqual(a.score_mean[0],2.);self.assertAlmostEqual(a.score_sd[0],np.sqrt(2))
 def test_m0_correlations_undefined(self):
  d=pd.DataFrame(dict(epistasis=[0.,2.,-2.],pred_epistasis=[0.,0.,0.],z_ab=[0.,2.,-2.],pred_z_ab=[0.,0.,0.]));s=score(d);self.assertTrue(np.isnan(s['epi_spearman']));self.assertEqual(s['epi_auroc'],.5);d.epistasis=2.;self.assertTrue(np.isnan(score(d)['epi_auroc']))
 def test_prediction_coverage_keys_reconstruction(self):
  d=pd.DataFrame(dict(assay=['a','a'],mutant=['A1C:D2E','A1G:D2E'],z_a=[1.,2.],z_b=[3.,4.],z_ab=[5.,7.]));p=d[['assay','mutant']].copy();p['pred_epistasis']=[.2,.3];p['pred_z_ab']=d.z_a+d.z_b+p.pred_epistasis;validate(d,p)
  with self.assertRaises(ValueError):validate(d,p.iloc[:1])
  with self.assertRaises(ValueError):validate(d,p.iloc[[0,0]])
  p.pred_z_ab+=1
  with self.assertRaises(ValueError):validate(d,p)
 def test_nested_group_disjointness(self):
  d=pd.DataFrame({'UniProt_ID':np.repeat([f'p{i}' for i in range(15)],3),'cluster':np.repeat([f'c{i//2}' for i in range(15)],3)})
  for col in ['UniProt_ID','cluster']:
   out=group_folds(d,col,5)
   for f in range(5):
    tr=d[out!=f];te=d[out==f];self.assertFalse(set(tr[col])&set(te[col]));self.assertFalse(set(tr.UniProt_ID)&set(te.UniProt_ID));inner=group_folds(tr,col,3)
    for i in range(3):self.assertFalse(set(tr[inner!=i][col])&set(tr[inner==i][col]))
 def test_cluster_bootstrap_keeps_multiplicity(self):
  p=pd.DataFrame(dict(assay=['a','b','c'],UniProt_ID=['p','q','r']));cl=pd.DataFrame(dict(UniProt_ID=['p','q','r'],cluster=['x','x','y']));rows=[]
  for m in ['M1','M2']:
   for s in [0,1,2]:
    for i,k in enumerate(['p','q','r']):
     x=.1+(.3*i if m=='M2' else 0);rows.append(dict(model=m,seed=s,UniProt_ID=k,assay=['a','b','c'][i],epi_spearman=x,epi_auroc=x,epi_rmse=x,z_spearman=x,z_rmse=x))
  t=pd.DataFrame(rows);out=paired_ci({'protein':t.drop(columns='assay'),'assay':t.drop(columns='UniProt_ID')},p,cl,'cluster',2000);r=out[(out.aggregation=='macro_protein')&(out.metric=='epi_spearman')].iloc[0];self.assertAlmostEqual(r.M2_minus_M1,.3);self.assertAlmostEqual(r.ci_low,.15);self.assertAlmostEqual(r.ci_high,.6)
 def test_atomic_failure_keeps_original(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'data.txt';p.write_text('complete')
   def fail(f):f.write('incomplete');raise RuntimeError('interrupted')
   with self.assertRaises(RuntimeError):write(p,fail)
   self.assertEqual(p.read_text(),'complete');self.assertEqual(len(list(Path(tmp).iterdir())),1)
if __name__=='__main__':unittest.main()

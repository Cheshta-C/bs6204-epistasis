"""Validate exported payload hashes and canonicalize temporary-write metadata only."""
import sys,json,zipfile,hashlib,shutil,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,MANIFEST,REGISTRY,publish,archive
from atomic_io import sha,csv_file,json_file
import pandas as pd
def digest_member(z,name):
 h=hashlib.sha256()
 with z.open(name) as inp:
  for chunk in iter(lambda:inp.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def inspect(path,manifest):
 changes={};jobs=set();checked=0
 with zipfile.ZipFile(path) as z:
  names=set(z.namelist());assert z.testzip() is None,path
  for name in names:
   if 'runs/durable_v2/' in name and name.endswith('/verification.json'):
    job=name.split('runs/durable_v2/',1)[1].rsplit('/verification.json',1)[0];expected=manifest['jobs'][job]['files'];r=json.loads(z.read(name));assert r['signature']==manifest['jobs'][job]['signature'] and r['inference_verified'];assert all(r['files'].get(n)==s for n,s in expected.items());extra=set(r['files'])-set(expected);assert all(n.endswith('.partial') for n in extra),'Unexpected extra scientific file reference'
    prefix=name.rsplit('/',1)[0]+'/'
    for n,s in expected.items():assert prefix+n in names and digest_member(z,prefix+n)==s,(path.name,job,n)
    checked+=len(expected);jobs.add(job)
    if extra:r['files']=expected;changes[name]=(json.dumps(r,indent=2,allow_nan=False)+'\n').encode()
   elif name.endswith('/search_verification.json'):
    r=json.loads(z.read(name));prefix=name.rsplit('/',1)[0]+'/'
    for n,s in r['files'].items():assert prefix+n in names and digest_member(z,prefix+n)==s,(path.name,n)
    checked+=len(r['files'])
   elif name.endswith('/verification.json'):
    r=json.loads(z.read(name))
    if isinstance(r.get('files'),dict):
     expected={n:s for n,s in r['files'].items() if not n.endswith('.partial')};prefix=name.rsplit('/',1)[0]+'/'
     for n,s in expected.items():assert prefix+n in names and digest_member(z,prefix+n)==s,(path.name,n)
     checked+=len(expected)
     if expected!=r['files']:r['files']=expected;changes[name]=(json.dumps(r,indent=2,allow_nan=False)+'\n').encode()
 return changes,jobs,checked
def rewrite(path,changes):
 tmp=path.with_suffix('.canonicalizing')
 with zipfile.ZipFile(path) as old,zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as new:
  info={i.filename:(i.CRC,i.file_size) for i in old.infolist()}
  for member in old.infolist():
   if member.filename in changes:new.writestr(member.filename,changes[member.filename])
   else:
    with old.open(member) as inp,new.open(member.filename,'w') as out:shutil.copyfileobj(inp,out,1024*1024)
 with zipfile.ZipFile(tmp) as z:
  assert z.testzip() is None and set(z.namelist())==set(info)
  for i in z.infolist():
   if i.filename not in changes:assert (i.CRC,i.file_size)==info[i.filename],'Non-metadata payload changed'
 with open(tmp,'rb') as f:os.fsync(f.fileno())
 os.replace(tmp,path)
def main():
 manifest=json.load(open(MANIFEST));rows=[];individual=BASE/'individual_archive_audit';required=[]
 for job,rec in manifest['jobs'].items():
  assert rec['verified'] and rec['persisted'];p,model,fold,seed=job.split('/');name=f'BS6204_{model}_{p}_f{fold.split("_")[-1]}_s{seed.split("_")[-1]}.zip';required.append((individual/name,job))
 assert len(required)==90,'All primary and predefined diagnostic jobs must be complete'
 required += [(DURABLE/n,None) for n in ['BS6204_M1_Protein_Results.zip','BS6204_M2_Protein_Results.zip','BS6204_Cluster_Results.zip','BS6204_Structural_Ablations.zip','BS6204_M0_Baseline.zip']]
 for path,job in required:
  m=json.load(open(MANIFEST));receipt=json.load(open(REGISTRY))[path.name];assert path.is_file() and sha(path)==receipt['sha256'],path.name;before=sha(path);changes,jobs,checked=inspect(path,m)
  if job:assert jobs=={job}
  if changes:
   rewrite(path,changes);after_changes,after_jobs,_=inspect(path,m);assert not after_changes and jobs==after_jobs
   publish(path,job=job,job_record=m['jobs'][job] if job else None)
  rows.append({'artifact':path.name,'unique_jobs_in_archive':len(jobs),'required_payload_hashes_verified':checked,'metadata_records_canonicalized':len(changes),'scientific_payloads_unchanged':True,'sha256_before':before,'sha256_after':sha(path)});print('ARCHIVE VERIFIED',path.name,'metadata fixes',len(changes),flush=True)
 out=BASE/'artifacts/verification';csv_file(pd.DataFrame(rows),out/'exported_archive_integrity_audit.csv');json_file({'individual_job_archives_verified':90,'aggregate_model_and_baseline_archives_verified':5,'all_required_payload_hashes_match_replayed_files':True,'only_nonessential_temporary_write_metadata_removed':True,'scientific_model_prediction_config_metric_bytes_changed':False,'archives_with_metadata_corrections':sum(r['metadata_records_canonicalized']>0 for r in rows)},out/'exported_archive_integrity_audit.json');z=DURABLE/'BS6204_Verification_Records.zip';archive(z,[(f,'artifacts/verification/'+str(f.relative_to(out))) for f in out.rglob('*') if f.is_file()]);publish(z);print('ALL 95 MODEL/BASELINE ARCHIVES AND THEIR AUTHORITATIVE FILE MAPS VERIFIED',flush=True)
if __name__=='__main__':main()

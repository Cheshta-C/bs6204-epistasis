"""Preserve completed primary evidence, then finish predefined diagnostics and record audit."""
import sys,json,subprocess,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,MANIFEST,archive,publish
from atomic_io import json_file
def main():
 w=BASE/'artifacts';v=json.load(open(w/'verification/verification.json'));assert v['checkpoints_verified']==60 and v['evaluation_csv_byte_identical'] and v['all_seed_packages_persisted']
 m=json.load(open(MANIFEST));m['status']='all_60_primary_checkpoints_verified_predefined_diagnostics_next';m['primary_verification']=v;m['updated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();json_file(m,MANIFEST)
 files=[(p,'artifacts/'+str(p.relative_to(w))) for folder in [w/'evaluation',w/'verification',w/'environment'] for p in folder.rglob('*') if p.is_file()];files.append((MANIFEST,MANIFEST.name));archive(DURABLE/'BS6204_Primary_Verification.zip',files);publish(DURABLE/'BS6204_Primary_Verification.zip')
 subprocess.run([sys.executable,'-u',str(ROOT/'package_code.py')],check=True)
 subprocess.run([sys.executable,'-u',str(ROOT/'run_ablations.py')],check=True)
 subprocess.run([sys.executable,'-u',str(ROOT/'audit_saved_records.py')],check=True)
 print('PRIMARY STUDY, STRUCTURAL DIAGNOSTICS AND SAVED-RECORD AUDIT COMPLETE',flush=True)
if __name__=='__main__':main()

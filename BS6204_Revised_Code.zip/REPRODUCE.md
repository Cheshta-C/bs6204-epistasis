# Reproduce the corrected original epistasis study

The original repository at commit 404f8bbba83f3ecfa92f1de0d43d89385db1d0ee is authoritative.
The delivered Git bundle includes that commit and the corrected branch. The original source
is also preserved unchanged under historical/404f8bb. All reported models use the genuine
frozen ESM-2 650M cache and original 128-wide architectures.

## Inspect the completed study without retraining

Create a workspace and obtain the delivered archives. Extract the revised-code ZIP to a
temporary directory, then clone its BS6204_Code_Branch.bundle as bs6204-epistasis/ (branch
fix/epistasis-nested-validation). Alternatively place the ZIP's flat code tree in that folder.
Use the Git-bundle checkout for resumed training/export; the flat tree supports offline replay.
Extract the following archives at workspace root:

- BS6204_Canonical_Input_Tables.zip
- BS6204_Preprocessing_Audit.zip
- BS6204_Recovered_Configuration.zip
- BS6204_M1_Protein_Results.zip
- BS6204_M2_Protein_Results.zip
- BS6204_Cluster_Results.zip
- BS6204_Structural_Ablations.zip
- BS6204_M0_Baseline.zip
- BS6204_Public_Source_Resources.zip

Extract BS6204_Embedding_Cache.zip into artifacts/ (its members start with caches/). Put the
latest BS6204_Progress_Manifest.json in durable/. The flat extraction yields artifacts/inputs,
artifacts/caches, artifacts/clusters and artifacts/runs/durable_v2. Do not use partial older
embedding-cache versions. No need to re-embed or refit when verified artifacts exist.

Use Python 3.12 and the supplied requirements-corrected.lock.txt. Install the exact CPU
Torch wheel from https://download.pytorch.org/whl/cpu, then the remaining pinned packages.
The reference execution environment is Linux; use Linux or WSL2 for its POSIX file locks
and the supplied MMseqs2 executable. Preserve LF line endings in the source-hashed modules.
From the workspace:

```bash
export BS6204_WORKSPACE="$PWD"
export OPENBLAS_NUM_THREADS=1
python -m unittest discover -s bs6204-epistasis/tests -v
python bs6204-epistasis/src/verify_all.py artifacts
python - <<'PY'
import sys
import pandas as pd
sys.path.insert(0, 'bs6204-epistasis')
from run_ablations import verify
rows = verify('no_contacts') + verify('no_distance')
assert len(rows) == 30
pd.DataFrame(rows).to_csv('artifacts/verification/offline_ablation_replay.csv', index=False)
PY
python bs6204-epistasis/audit_saved_records.py
python bs6204-epistasis/make_final_outputs.py
```

The verifier replays all 60 checkpoints and requires exact saved-file hashes, group
separation, complete keys, common M1/M2 splits and byte-identical regenerated evaluation CSVs.
The report generator refuses incomplete verification. PDF visual review is required before
final publication. Model-definition sources must remain byte-identical to the recorded
signatures during replay; modifying a source file defines a new experiment.

## Recover original public inputs

Run prepare_from_public.py only for genuinely missing resources. It checks exact archive
hashes and refuses silent source changes. --rebuild-inputs reconstructs original pair
selection, singles-only normalization and original structure features; --regenerate-embeddings
explicitly regenerates real ESM-2 features if the cache is absent. Encoder weights are about
2.6 GB and remain referenced by original URL and SHA-256; their smaller reusable features
are supplied. The exact MMseqs2 binary archive is included because its public latest URL can
change. src/prepare_audit.py independently verifies normalization intervention, original
source replay, cohort hash, mapping and recovered MMseqs2 components.

## Resume genuinely missing training

Do not delete valid jobs or use console scores as completion evidence. Restore the latest
manifest, individual verified seed/search packages or complete model packages, and the
export receipt registry. The manifest's artifacts map can recover per-filename receipts;
confirm current remote versions before replacement. The pipeline skips only actual files
whose signatures, hashes, metrics and checkpoint replay pass and whose exports are confirmed.

The hosted persistence gate uses current authenticated Library helpers. This checkout
expects those in .persistent_export_v2/ under BS6204_WORKSPACE. The code ZIP includes the
helpers used by this study for provenance; on a new hosted session obtain the current
Library skill helpers rather than relying on stale authorization. No credentials are stored
in the code ZIP. Offline evaluation and replay do not write remotely or require those helpers.

```bash
python -u bs6204-epistasis/run_project.py
python -u bs6204-epistasis/complete_diagnostics.py
```

Priority is M1 protein, M2 protein, M1 cluster, M2 cluster. Every completed final fit saves its
checkpoint immediately, then predictions and records; replay and acknowledged export gate
the next seed. Four independent outer-fold workers use two Torch threads each. Changing the
dataset, architecture, target, grouping or search budget to accelerate training is forbidden.
If a remote export fails, resolve its actual state before clearing the failure marker; do
not automatically retry an uncertain upload or infer that temporary local files are durable.

## Targets, inference and interpretation

Primary true interaction is zAB-zA-zB. Normalization uses all measured singles of each assay
and sample SD ddof=1. Singles for a held-out protein are assumed available. There is no fitted
double-mutant reference. Reconstructed effect is zA+zB+predicted interaction. Baseline M0 is
untrained and constant-zero for interaction; it has a model definition rather than learned
weights and no random-seed variation. Rank correlation for M0 is undefined.

Five outer and three inner folds, three optimizer/dropout candidates, three final seeds,
40-epoch cap and patience five are fixed in configs/nested_v1.json. Inner protein-macro
interaction Spearman selects configuration and stopping; outer outcomes never select them.
Cluster robustness keeps whole MMseqs2 components in both levels. Paired confidence intervals
resample whole groups and condition on the saved OOF fits, rather than refitting per draw.
Optional structural ablation scores must never be inferred from contact-stratified metrics.

## Prediction column guide

`pair_id` is `assay::mutant`; `assay` identifies the ProteinGym assay and `UniProt_ID` the
protein. `cluster` identifies its MMseqs2 component. `outer_fold` records the actual evaluation
split, and `seed`, `model`, and `protocol` identify the fit. The original input `fold` column
remains as preprocessing provenance. Use `outer_fold` for the protocol's held-out assignment.

`true_epistasis` is `z_ab-z_a-z_b`, and `pred_epistasis` is its signed prediction.
`pred_z_ab` is `z_a+z_b+pred_epistasis`. Strong-epistasis AUROC uses `abs(true_epistasis)>1`
and the score `abs(pred_epistasis)`. `dist_3d` is a minimum heavy-atom distance in Angstrom;
`seq_distance` is the absolute positional separation. M0's seed field is deterministic
bookkeeping, with no random-seed uncertainty or fitted weights.
Channel masks are recorded in the checkpoint signature. Source distance columns and contact
files retain their original measurements when a channel is masked inside model execution.

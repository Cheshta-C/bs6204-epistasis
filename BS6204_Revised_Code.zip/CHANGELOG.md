# Corrections to the original BS6204 project

Starting commit: 404f8bbba83f3ecfa92f1de0d43d89385db1d0ee.

- `build_pairs.py`: singles-only mean/sample SD; naive interaction labels; no double-outcome
  Huber fit; original filters, minimum, cap, seed and pair ordering retained; atomic exports.
- `train_m1.py`: original width-128 model with symmetric effect scalars, default 650M;
  corrected masking diagnostic uses naive labels; historical no-singles code preserved.
- `train_m2.py`: same original projection, two GCN layers, site/head dimensions and graph;
  symmetric effect scalars, explicit cache loading.
- `structure_features.py`: explicit A4 exclusion, exact file priority, mapping evidence,
  atomic output; removes invalid pair-level significance/structural-utility verdict.
- `eval_harness.py`, `compare_ci.py`, `slice_eval.py`: common naive residual rather than
  held-out fitted reference; stricter coverage in harness/CI; neutral geometry plot title.
- `model_runtime.py`: original classes, width 128 and MSE; algebraically equivalent M1
  context factoring and sparse disconnected M2 graph execution; equivalence/gradient tests.
- `nested_runner.py`: fixed nested selection, fresh final seeds, no outer stopping,
  complete checkpoint/prediction/configuration/label/history/metric records. Actual model
  inference is independently replayed using the original class execution before export.
- `persistence.py`, `atomic_io.py`: complete-only file publication; every final seed and
  selected search exported, acknowledged and recorded before advancing; failures halt.
- `evaluate_results.py`: residual-focused metrics at protein/assay/pooled levels, all
  seeds, threshold sensitivity, geometry and paired protein/component bootstrap intervals.
- `verify_all.py`: all actual checkpoints, actual split separation, M1/M2 split equality,
  complete prediction keys and byte-identical saved-table replay.
- `prepare_audit.py`, `regenerate_embeddings.py`: original public-resource reconstruction,
  exact original counts and pair hash, raw-single intervention, structure/sequence checks,
  real frozen 650M embeddings and independently verified MMseqs2 components.
- `run_project.py`: required priority order, independent fold scheduling, per-phase exports.

Historical source/README and original notebooks/tables are retained. Old fitted-reference
scores are not new nested results. No redesigned-project dataset, trained M0 calibration,
64/96-width replacement, or A4 primary assay was introduced. Preprocessing affects the
numerical target scale. Symmetry affects architecture inputs without changing dimensions.
Nested selection, resampling and homology protocols affect evaluation and interpretation.
The earlier console-only M1 values remain provisional until new saved predictions verify them.

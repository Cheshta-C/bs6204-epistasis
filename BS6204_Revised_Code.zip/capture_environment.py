"""Record package versions and runtime details without secrets or environment variables."""
import sys,json,platform,importlib.metadata as md
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE
from atomic_io import json_file
def main():
 out=BASE/'artifacts/environment';out.mkdir(exist_ok=True);lock={}
 for line in (ROOT/'requirements-corrected.lock.txt').read_text().splitlines():
  if '==' in line:
   n,v=line.split('==');actual=md.version(n);lock[n]={'expected':v,'actual':actual,'match':v==actual}
 assert all(r['match'] for r in lock.values()),'Locked dependencies differ'
 snapshot={'python':sys.version,'platform':platform.platform(),'torch_version':str(torch.__version__),'cpu_capability':torch.backends.cpu.get_cpu_capability(),'training_torch_threads_per_worker':2,'maximum_outer_workers':4,'locked_dependency_check':lock,'installed_distributions':sorted([{'name':d.metadata['Name'],'version':d.version} for d in md.distributions()],key=lambda r:r['name'].lower()),'secrets_and_environment_variables_excluded':True};json_file(snapshot,out/'dependency_and_runtime_snapshot.json');(out/'torch_build_config.txt').write_text(torch.__config__.show());print('All pinned dependencies match; runtime snapshot saved')
if __name__=='__main__':main()

"""Recompute stopping/selection decisions and validate final histories from saved files."""
import sys,json,hashlib
from pathlib import Path
import numpy as np,pandas as pd,torch
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,MANIFEST
from atomic_io import sha,csv_file,json_file
from scientific_metrics import METRICS
def main():
 w=BASE/'artifacts';cfg=json.load(open(ROOT/'configs/nested_v1.json'));m=json.load(open(MANIFEST));folds={};rows=[];torch.set_num_threads(2)
 for key,rec in m['jobs'].items():
  assert rec.get('verified') and rec.get('persisted'),key
  folder=w/'runs/durable_v2'/key;assert all((folder/n).is_file() and sha(folder/n)==s for n,s in rec['files'].items());fo=folder.parent
  if str(fo) not in folds:
   h=pd.read_csv(fo/'inner_history.csv');c=pd.read_csv(fo/'candidates.csv');sel=json.load(open(fo/'selection.json'));assert len(c)==9;candidate_scores={};bestepochs={}
   for candidate,params in enumerate(cfg['candidates']):
    weighted=[];counts=[];eps=[]
    for inner in range(3):
     g=h[(h.candidate==candidate)&(h.inner_fold==inner)].sort_values('epoch');assert np.array_equal(g.epoch,np.arange(1,len(g)+1));assert 1<=len(g)<=cfg['max_epochs'];assert np.isfinite(g[['train_mse','validation_mse']]).all().all() and (g[['train_mse','validation_mse']]>=0).all().all();assert np.allclose(g.validation_rmse,np.sqrt(g.validation_mse),atol=1e-12)
     best=-np.inf;epbest=0;wait=0;eligible=0
     for _,r in g.iterrows():
      assert wait<cfg['patience'],'History continued beyond predefined stopping'
      if np.isfinite(r.interaction_spearman) and r.interaction_spearman>best+cfg['min_delta']:best=r.interaction_spearman;epbest=int(r.epoch);eligible=int(r.eligible_proteins);wait=0
      else:wait+=1
     assert len(g)==cfg['max_epochs'] or wait==cfg['patience'];saved=c[(c.candidate==candidate)&(c.inner_fold==inner)].iloc[0];assert epbest==saved.best_epoch and len(g)==saved.epochs_run and eligible==saved.eligible_proteins and np.isclose(best,saved.best_spearman,atol=1e-12,rtol=0)
     for name,value in params.items():assert np.isclose(saved[name],value,atol=1e-15,rtol=0)
     weighted.append(best*eligible);counts.append(eligible);eps.append(epbest)
    candidate_scores[candidate]=sum(weighted)/sum(counts);bestepochs[candidate]=eps
   chosen=0
   for candidate in range(1,3):
    if candidate_scores[candidate]>candidate_scores[chosen]+cfg['min_delta']:chosen=candidate
   assert sel['candidate']==chosen and np.isclose(sel['score'],candidate_scores[chosen],atol=1e-12,rtol=0);assert sel['inner_best_epochs']==bestepochs[chosen] and sel['epochs']==max(1,int(np.floor(np.median(bestepochs[chosen])+.5)))
   for name,value in cfg['candidates'][chosen].items():assert sel[name]==value
   folds[str(fo)]=sel
  sel=folds[str(fo)];saved=json.load(open(folder/'configuration.json'));assert saved==sel;h=pd.read_csv(folder/'training_history.csv');assert len(h)==sel['epochs'] and np.array_equal(h.epoch,np.arange(1,len(h)+1));seed=int(key.rsplit('_',1)[1]);assert (h.seed==seed).all() and np.isfinite(h.train_mse).all() and (h.train_mse>=0).all();ck=torch.load(folder/'checkpoint.pt',map_location='cpu',weights_only=True);assert ck['seed']==seed and ck['configuration']==sel and ck['calibration_parameters'] is None and ck['target']=='naive_epistasis';assert ck['signature']['hidden']==128 and ck['signature']['emb_dim']==1280
  metrics=json.load(open(folder/'metrics.json'))
  for level,col in [('protein','UniProt_ID'),('assay','assay')]:
   g=pd.read_csv(folder/f'per_{level}.csv');assert not g[col].duplicated().any() and int(g.n.sum())==rec['n_test']
   for name in METRICS:assert np.isclose(g[name].mean(),metrics['macro_'+level][name],atol=1e-12,rtol=0,equal_nan=True)
  fingerprint=hashlib.sha256()
  for name,tensor in sorted(ck['state_dict'].items()):
   assert torch.isfinite(tensor).all();fingerprint.update(name.encode());fingerprint.update(tensor.contiguous().numpy().tobytes())
  rows.append(dict(job=key,outer_job=key.rsplit('/',1)[0],final_epochs=sel['epochs'],candidate=sel['candidate'],seed=seed,learned_weights_sha256=fingerprint.hexdigest(),history_and_selection_verified=True,calibration_parameters='none',authoritative_files_verified=True))
 table=pd.DataFrame(rows)
 for _,group in table.groupby('outer_job'):assert set(group.seed)=={0,1,2} and group.learned_weights_sha256.nunique()==3,'Final seeds do not have distinct learned states'
 out=w/'verification';csv_file(table,out/'selection_and_training_record_audit.csv');json_file({'jobs_verified':len(rows),'selected_searches_verified':len(folds),'nine_inner_fits_per_search':True,'epoch_stopping_recomputed':True,'candidate_selection_recomputed':True,'final_histories_match_selected_epochs':True,'all_original_hidden_width_128':True,'no_fitted_double_reference':True,'per_group_metrics_match_summary':True,'distinct_learned_states_for_all_final_seeds':True,'all_model_weights_finite':True},out/'selection_and_training_record_audit.json');print('PASS',len(rows),'final jobs and',len(folds),'actual selection histories',flush=True)
if __name__=='__main__':main()

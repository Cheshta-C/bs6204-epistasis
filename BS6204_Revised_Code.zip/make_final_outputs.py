"""Author final figures/report/presentation content only from fully verified runs."""
import json,sys,datetime,textwrap
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Image,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from matplotlib.font_manager import findfont,FontProperties
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from persistence import BASE
from atomic_io import json_file,sha
from evaluate_results import paired_ci
from model_runtime import make_model

LABELS={'epi_spearman':'Interaction Spearman','epi_auroc':'Strong-epistasis AUROC','epi_rmse':'Interaction RMSE','z_rmse':'Double-mutant RMSE','z_spearman':'Double-mutant Spearman'}
PRIMARY=['epi_spearman','epi_auroc','epi_rmse']
PROTOCOLS=['protein','cluster']
PALETTE={'M0':'#8592a3','M1':'#167d9a','M2':'#df8241'}
def fmt(x,n=6):return f'{float(x):.{n}f}' if pd.notna(x) else 'undefined'

def main():
 w=BASE/'artifacts';v=json.load(open(w/'verification/verification.json'));assert v['checkpoints_verified']==60 and v['evaluation_csv_byte_identical'] and v['all_seed_packages_persisted']
 out=w/'final';fig=out/'figures';fig.mkdir(parents=True,exist_ok=True)
 specs={}
 for model in ['M1','M2']:
  net=make_model(model,{'dropout':.1});specs[model]={'frozen_encoder':'esm2_t33_650M_UR50D','encoder_layer':33,'embedding_dimension':1280,'hidden_width':128,'nominal_trainable_parameters':sum(p.numel() for p in net.parameters() if p.requires_grad),'state_shapes':{n:list(t.shape) for n,t in net.state_dict().items()},'dropout_selected_per_outer_fold':True}
 json_file(specs,out/'model_specifications.json')
 ap=w/'ablations/verification.json';have_ablations=ap.exists()
 if have_ablations:
  av=json.load(open(ap));assert av['all_requested_ablations_complete'] and av['checkpoints_verified']==30 and av['same_pairs_and_splits_as_primary']
  ab=pd.read_csv(w/'ablations/evaluation/metrics_by_seed.csv');aci=pd.read_csv(w/'ablations/paired_channel_comparisons.csv')
 record_audit=json.load(open(w/'verification/selection_and_training_record_audit.json'));assert record_audit['jobs_verified']==60+(30 if have_ablations else 0) and record_audit['distinct_learned_states_for_all_final_seeds'] and record_audit['all_model_weights_finite']
 by={p:pd.read_csv(w/f'evaluation/{p}/metrics_by_seed.csv') for p in PROTOCOLS}
 cis={p:pd.read_csv(w/f'evaluation/{p}/paired_confidence_intervals.csv') for p in PROTOCOLS}
 allseeds=pd.concat([t.assign(protocol=p) for p,t in by.items()],ignore_index=True);allseeds.to_csv(out/'all_metrics_by_seed.csv',index=False)
 allcis=pd.concat([t.assign(protocol=p) for p,t in cis.items()],ignore_index=True);allcis.to_csv(out/'all_paired_confidence_intervals.csv',index=False)
 baseline_ci=[]
 pairs=pd.read_csv(w/'inputs/pairs_struct.csv');clusters=pd.read_csv(w/'clusters/clusters.csv')
 for p in PROTOCOLS:
  source={level:pd.read_csv(w/f'evaluation/{p}/per_{level}.csv') for level in ['protein','assay']}
  for compared in ['M1','M2']:
   tables={level:t[t.model.isin(['M0',compared])].assign(model=lambda x:x.model.map({'M0':'M1',compared:'M2'})) for level,t in source.items()}
   c=paired_ci(tables,pairs,clusters,p).rename(columns={'M1':'reference_value','M2':'compared_value','M2_minus_M1':'compared_minus_reference','M1_ci_low':'reference_ci_low','M1_ci_high':'reference_ci_high','M2_ci_low':'compared_ci_low','M2_ci_high':'compared_ci_high'});c['reference_model']='M0';c['compared_model']=compared;c['protocol']=p;baseline_ci.append(c)
 baseline_ci=pd.concat(baseline_ci,ignore_index=True);baseline_ci.to_csv(out/'paired_comparisons_with_M0.csv',index=False)
 summary=allseeds.groupby(['protocol','aggregation','model'])[list(LABELS)].agg(['mean','std']).reset_index();summary.columns=['_'.join(c).rstrip('_') for c in summary.columns];summary.to_csv(out/'all_metrics_summary.csv',index=False)
 selection=[]
 for p in PROTOCOLS:
  for m in ['M1','M2']:
   for f in range(5):
    folder=w/f'runs/durable_v2/{p}/{m}/fold_{f}';s=json.load(open(folder/'selection.json'));c=pd.read_csv(folder/'candidates.csv');selection.append(dict(protocol=p,model=m,outer_fold=f,**s,inner_epoch_cap_hits=int(c.reached_epoch_cap.sum()),inner_fits=len(c)))
 pd.DataFrame(selection).to_csv(out/'model_selection_summary.csv',index=False)
 # Exact numeric source tables accompany every figure.
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':200,'svg.fonttype':'none','pdf.fonttype':42})
 chart=[]
 for p in PROTOCOLS:
  t=by[p];t=t[t.aggregation=='macro_protein']
  f,axs=plt.subplots(1,3,figsize=(10.6,3.3))
  for ax,k in zip(axs,PRIMARY):
   for j,m in enumerate(['M0','M1','M2']):
    values=t[t.model==m][k];mean=values.mean();row={'protocol':p,'model':m,'metric':k,'mean':mean,'seed_sd':values.std()}
    if m!='M0':
     c=cis[p].query("aggregation=='macro_protein' and metric==@k").iloc[0];lo,hi=c[m+'_ci_low'],c[m+'_ci_high'];row.update(ci_low=lo,ci_high=hi);ax.errorbar(j,mean,yerr=[[mean-lo],[hi-mean]],fmt='o',color=PALETTE[m],capsize=4,ms=7)
    elif np.isfinite(mean):ax.plot(j,mean,'o',color=PALETTE[m],ms=7)
    else:ax.text(j,.05,'undefined',rotation=90,va='bottom',ha='center',transform=ax.get_xaxis_transform(),color=PALETTE[m])
    chart.append(row)
   ax.set(xticks=[0,1,2],xticklabels=['M0','M1','M2'],xlim=(-.4,2.4),title=LABELS[k]);ax.grid(axis='y',alpha=.2)
  f.suptitle(('Protein-grouped' if p=='protein' else 'Sequence-cluster-disjoint')+' | protein-macro performance',fontweight='bold');f.tight_layout()
  for ext in ['png','svg','pdf']:f.savefig(fig/f'{p}_performance.{ext}',bbox_inches='tight')
  plt.close(f)
 pd.DataFrame(chart).to_csv(fig/'performance_source.csv',index=False)
 f,axs=plt.subplots(1,3,figsize=(10.6,3.3))
 for ax,k in zip(axs,PRIMARY):
  for i,p in enumerate(PROTOCOLS):
   r=cis[p].query("aggregation=='macro_protein' and metric==@k").iloc[0];mu=r.M2_minus_M1
   ax.errorbar(mu,i,xerr=[[mu-r.ci_low],[r.ci_high-mu]],fmt='o',color=['#167d9a','#df8241'][i],capsize=4)
  ax.axvline(0,color='#888',lw=1);ax.set(yticks=[0,1],yticklabels=['Protein','Cluster'],title=LABELS[k],xlabel='M2 minus M1');ax.grid(axis='x',alpha=.2)
 f.suptitle('Paired whole-group bootstrap | 95% percentile intervals',fontweight='bold');f.tight_layout()
 for ext in ['png','svg','pdf']:f.savefig(fig/f'paired_differences.{ext}',bbox_inches='tight')
 plt.close(f)
 # Protein distributions identify whether pooled gains hide heterogeneous behavior.
 rows=[];f,axs=plt.subplots(1,2,figsize=(9.6,4.1))
 for ax,p in zip(axs,PROTOCOLS):
  t=pd.read_csv(w/f'evaluation/{p}/per_protein.csv');z=t[t.model.isin(['M1','M2'])].groupby(['UniProt_ID','model']).epi_spearman.mean().unstack();z.to_csv(fig/f'{p}_protein_spearman_source.csv');ax.scatter(z.M1,z.M2,s=22,color='#167d9a',alpha=.8);ax.plot([-1,1],[-1,1],color='#aaa',lw=1);ax.set(xlim=(-.6,1),ylim=(-.6,1),xlabel='M1 interaction Spearman',ylabel='M2 interaction Spearman',title=p.capitalize()+' holdout');ax.set_aspect('equal')
 f.tight_layout()
 for ext in ['png','svg','pdf']:f.savefig(fig/f'per_protein_comparison.{ext}',bbox_inches='tight')
 plt.close(f)
 # Original architecture schematic as a vector scientific figure.
 f,axs=plt.subplots(2,1,figsize=(10.5,3.5));f.subplots_adjust(hspace=.5)
 def box(ax,x,text,width=.19):ax.text(x,.5,text,ha='center',va='center',transform=ax.transAxes,bbox=dict(boxstyle='round,pad=.5',facecolor='#eef5f8',edgecolor='#167d9a'),fontsize=11)
 for ax in axs:ax.axis('off')
 for ax,title,texts in [(axs[0],'M1',['Frozen ESM-2\n650M / 1,280','Shared site MLP\nWT + mutant AA\n128 / 128','Sum both sites\n+ symmetric singles\n+ sequence distance','128-wide head\nPredicted epistasis']), (axs[1],'M2',['Frozen ESM-2\n650M / 1,280','Projection 128\nTwo GCN layers\n128 / 128','Shared site MLP\nSum + singles\n+ 3D / seq distance','128-wide head\nPredicted epistasis'])]:
  ax.set_title(title,loc='left',fontweight='bold')
  for x,text in zip([.1,.36,.63,.89],texts):box(ax,x,text)
  for a,b in [(.19,.26),(.46,.51),(.75,.80)]:ax.annotate('',xy=(b,.5),xytext=(a,.5),xycoords='axes fraction',arrowprops=dict(arrowstyle='->',color='#555'))
 for ext in ['png','svg','pdf']:f.savefig(fig/f'architectures.{ext}',bbox_inches='tight')
 plt.close(f)
 # Exact presentation content, written after and from validated numerical tables.
 def primary_table(p):
  t=by[p].query("aggregation=='macro_protein'");lines=['| Model | Interaction Spearman | Interaction AUROC | Interaction RMSE |','|---|---:|---:|---:|']
  for m in ['M0','M1','M2']:lines.append('| '+m+' | '+' | '.join(fmt(t[t.model==m][k].mean()) for k in PRIMARY)+' |')
  return '\n'.join(lines)
 def ci_text(p):
  lines=[]
  for k in PRIMARY:
   r=cis[p].query("aggregation=='macro_protein' and metric==@k").iloc[0];lines.append(f'{LABELS[k]}: M2 - M1 = {fmt(r.M2_minus_M1)}; paired 95% CI [{fmt(r.ci_low)}, {fmt(r.ci_high)}].')
  return ' '.join(lines)
 slide=[]
 def S(title,bullets,figure,speaker):slide.append('## '+title+'\n\n'+'\n'.join('- '+x for x in bullets)+'\n\nFigure/source: '+figure+'\n\nSpeaker: '+speaker+'\n')
 S('1. Predicting variant-pair epistasis',['221,340 measured pairs, 47 assays, 45 proteins; identical M1/M2 population.','Primary epsilon = zAB - zA - zB; M0 predicts zero interaction.','Question: can sequence learning predict nonadditivity, and does the structure-aware model improve it?'],'architectures.svg; canonical matched table','We predict the departure from additive measured single-mutant effects. Accurate double-mutant scores alone do not establish accurate epistasis.')
 S('2. M1: frozen sequence features',['ESM-2 650M frozen, layer 33, 1,280 dimensions per residue.','Shared mutation-aware site MLP, hidden width 128; sum site representations.','Symmetric measured-single inputs: sum and absolute difference; scaled sequence distance.',f"{specs['M1']['nominal_trainable_parameters']:,} trainable parameters in the head."],'architectures.svg; train_m1.py; model_specifications.json','Only the mutation head is trained. Swapping the two mutation sites leaves inference predictions unchanged.')
 S('3. M2: the original two-layer GCN',['Frozen ESM features projected to 128; two graph-convolution layers of width 128.','Contacts, adjacent residues and self-loops with symmetric degree normalization.','Mutation-aware shared site encoder, symmetric inputs and direct 3D distance.',f"{specs['M2']['nominal_trainable_parameters']:,} trainable parameters; encoder remains frozen."],'architectures.svg; train_m2.py; model_specifications.json','The contact graph changes residue context before scoring each mutation. This comparison also changes architecture; a causal attribution solely to structural information requires ablation.')
 S('4. Training and nested validation',['Five outer folds and three inner folds; all assays of a protein stay together.','Three fixed optimizer/dropout candidates; inner protein-macro interaction Spearman selects hyperparameters.','Early stopping: 40-epoch cap, patience 5; fresh final seeds 0, 1, 2.','Normalization uses measured singles only; no fitted double-mutant reference.'],'model_selection_summary.csv; fold assignments and inner histories','Outer held-out outcomes never choose hyperparameters or training duration. The final duration is the rounded median of the selected candidate\'s three best inner epochs.')
 S('5. Metrics: interaction is the primary outcome',['Protein-macro interaction Spearman, strong-epistasis AUROC and interaction RMSE.','Strong epistasis: |epsilon| > 1; ranking score |predicted epsilon|.','Double-mutant RMSE and Spearman, assay-macro and pooled metrics are secondary.','M0 interaction Spearman is undefined; its AUROC is 0.5 when both classes exist.'],'all_metrics_by_seed.csv; all_metrics_summary.csv','Every reported number is recomputed from saved out-of-fold predictions. Residual and reconstructed-effect RMSE are equal by algebra, whereas their rank correlations differ.')
 S('6. Protein-grouped held-out performance',[primary_table('protein'),'Table values are means of three seed metrics, not prediction-ensemble scores.'],'protein_performance.svg / performance_source.csv','These are the completed held-out original-model results after the leakage and symmetry corrections. Error bars resample complete proteins and condition on the trained folds.')
 S('7. M1 versus M2',[ci_text('protein')],'paired_differences.svg / all_paired_confidence_intervals.csv','Positive differences favor M2 for correlation and AUROC; negative differences favor M2 for RMSE. Interpret the interval and per-protein heterogeneity together.')
 S('8. Sequence-cluster robustness',[primary_table('cluster'),'39 MMseqs2 components; identity 30%, coverage 80%, with a specified domain-overlap rule.','Both outer and inner folds keep whole similarity components together.',ci_text('cluster')],'cluster_performance.svg; paired_differences.svg; clustering_manifest.json','This is a separately fitted nested robustness experiment. The sequence rule reduces close-homolog overlap; it does not prove absence of remote homology.')
 if have_ablations:
  desc=[]
  for flag in ['no_contacts','no_distance']:
   t=ab[(ab.aggregation=='macro_protein') & (ab.model=='M2_'+flag)];desc.append(flag+': '+', '.join(LABELS[k]+' '+fmt(t[k].mean()) for k in PRIMARY)+'.')
  S('9. Structure-channel ablations',desc+['Same protein-grouped data, nested search budget and final seeds as full M2.','Contact removal retains sequence edges and direct distance; distance removal retains the contact GCN.'],'ablations/evaluation/metrics_by_seed.csv; paired_channel_comparisons.csv','These are separately retrained channel-removal diagnostics within M2. Compare paired ablated-minus-full intervals. They do not uniquely identify molecular interaction mechanisms.')
 S(('10' if have_ablations else '9')+'. Structural interpretation and limitations',['Inspect per-protein differences and near/far contact strata; these are descriptive diagnostics.','M2 versus M1 alone does not isolate structure from architectural changes.',('Thirty additional channel-ablation checkpoints were replayed.' if have_ablations else 'Optional retrained structural ablations were not run; no ablation scores are implied.'),'Measured singles are required; this is not a zero-shot epistasis predictor.','Naive residuals depend on assay scale and may include global nonlinear effects.'],'per_protein_comparison.svg; geometry_metrics.csv; threshold_sensitivity.csv','The evidence concerns held-out statistical epistasis on this selected, structure-covered population. It does not establish molecular interaction energies, universal protein generalization or causal structural effects.')
 (out/'BS6204_Presentation_Content.md').write_text('# Collocating or Interacting? Deep Learning of Variant-Pair Epistasis\n\nValidated presentation content and speaker explanations. Figure files are in figures/.\n\n'+'\n'.join(slide))
 # Fixed page plan keeps performance tables and their interpretation together.
 pdfmetrics.registerFont(TTFont('BSRegular',findfont('DejaVu Sans')));pdfmetrics.registerFont(TTFont('BSBold',findfont(FontProperties(family='DejaVu Sans',weight='bold'))));pdfmetrics.registerFontFamily('BSRegular',normal='BSRegular',bold='BSBold',italic='BSRegular',boldItalic='BSBold')
 styles=getSampleStyleSheet()
 for style in styles.byName.values():style.fontName='BSRegular'
 for name in ['Title','Heading1','Heading2','Heading3']:styles[name].fontName='BSBold'
 styles.add(ParagraphStyle(name='BodySmall',parent=styles['BodyText'],fontSize=9.4,leading=13,spaceAfter=7));styles['Title'].fontSize=24;styles['Title'].leading=29
 story=[]
 def P(s):story.append(Paragraph(s,styles['BodySmall']))
 def H(s):story.append(Paragraph(s,styles['Heading2']))
 def table(headers,rows,widths=None,compact=False):
  pad=3 if compact else 6;cells=[[Paragraph(str(x),styles['BodySmall']) for x in row] for row in [headers]+rows];t=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8f1f5')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#167d9a')),('BOTTOMPADDING',(0,0),(-1,-1),pad),('TOPPADDING',(0,0),(-1,-1),pad)]));story.append(t);story.append(Spacer(1,8 if compact else 10))
 def pic(name,width=6.8*inch,height=None):
  from PIL import Image as PILImage
  p=fig/name;im=PILImage.open(p);h=height or width*im.height/im.width;story.append(Image(str(p),width=width,height=h));story.append(Spacer(1,8))
 def page(title):story.append(PageBreak());story.append(Paragraph(title,styles['Heading1']))
 story.append(Paragraph('Collocating or Interacting?<br/>Deep Learning of Variant-Pair Epistasis',styles['Title']));story.append(Spacer(1,14))
 P('Validated original BS6204 study | Final scientific report | '+datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d UTC'))
 P('Primary question: can sequence-based deep learning predict pairwise protein epistasis beyond additive single-mutant effects, and does an explicit structure-aware model improve interaction prediction?')
 H('Evidence delivered')
 P('All 60 final checkpoints (two models, two protocols, five folds, three seeds) were saved and independently replayed against held-out predictions. Complete 221,340-pair out-of-fold coverage was verified for every model/protocol/seed. Final evaluation tables reproduce byte-for-byte from saved predictions. Every selected search and final seed has an acknowledged persistent checkpoint package.')
 if have_ablations:P('Thirty additional checkpoints independently evaluate the predefined contact-edge and direct-distance removals under protein-grouped nested validation, after all required primary and robustness experiments.')
 H('Protein-grouped primary outcomes')
 t=by['protein'].query("aggregation=='macro_protein'");table(['Model']+[LABELS[k] for k in PRIMARY],[[m]+[fmt(t[t.model==m][k].mean()) for k in PRIMARY] for m in ['M0','M1','M2']],[55,150,150,130])
 primary_differences=allcis[(allcis.aggregation=='macro_protein') & allcis.metric.isin(PRIMARY)];unresolved=bool(((primary_differences.ci_low<=0)&(primary_differences.ci_high>=0)).all())
 P('Values are protein-macro means across final seeds. M0 is untrained; its interaction rank correlation is undefined because every prediction is zero. '+('All three primary M2-minus-M1 intervals include zero under both protocols: this study does not establish a protein-macro improvement from the full structure-informed M2 model.' if unresolved else 'Protocol-specific paired uncertainty intervals are reported below.'))
 P('Previously printed M1 means (0.652907, 0.748953, 0.545685) were provisional recovery evidence only. They are not the source of any table in this report. Historical fitted-reference and corrected naive-residual metrics must not be treated as the same experiment.')
 page('1. Input recovery and exact cohort')
 P('Authoritative source: github.com/Cheshta-C/bs6204-epistasis, starting commit 404f8bbba83f3ecfa92f1de0d43d89385db1d0ee. The original source snapshot remains unchanged under historical/. Recovered records provided configuration and split evidence, but no missing checkpoints were inferred from printed scores.')
 table(['Resource','Recovery and verification'],[['Mutation data','Original public ProteinGym DMS archive; source replay reproduced the original pair selection and order. Full sequence set: 235,355 pairs / 48 assays / 46 proteins.'],['Matched primary cohort','221,340 pairs / 47 assays / 45 proteins; A4_HUMAN excluded as originally specified. Matched table SHA-256: '+sha(w/'inputs/pairs_struct.csv')],['Frozen embeddings','Genuine ESM-2 650M pretrained weights; full wild-type sequences, layer 33, 1,280 dimensions, FP32 cache. No mock embeddings in any reported fit.'],['Structure','Original public ProteinGym AF2 structures, reconstructed contacts and pair distances; explicit residue mapping audit with 7,126 matched residues and zero identity mismatches.'],['Grouping','45 proteins; 39 independently regenerated MMseqs2 similarity components reproduce the recovered mapping.'],['Provenance','Source URLs, public archive checksums, model/cache checksums, pinned metadata, dependencies, commands and normalization interventions are in the supplied audit/configuration archives.']],[110,375])
 P('M1 and M2 use exactly the same structure-covered rows and splits within each protocol. No dataset or architecture from the previously redesigned project was substituted. Raw public encoder weights remain downloadable; the reusable embedding cache is included separately to avoid repeatedly embedding sequences.')
 page('2. Targets, models and scientific corrections')
 P('For each assay, normalize using the measured single-mutant mean and sample standard deviation (ddof=1). Apply those parameters to singles and doubles. Primary true interaction epsilon = zAB - zA - zB. Models minimize interaction MSE; reconstruct the double-mutant score as predicted zAB = zA + zB + predicted epsilon. M0 predicts epsilon = 0 without fitting. No double-mutant fitted reference or calibration is used in the primary analysis.')
 pic('architectures.png',width=6.7*inch)
 P('M1: frozen per-residue sequence contexts, learned 16-dimensional WT/mutant amino-acid embeddings, shared two-layer 128-wide site MLP, sum of the two site vectors, and a 128-wide output head. Scalars: zA+zB, |zA-zB| and clipped sequence distance/100.')
 P('M2: original 1,280-to-128 projection, two 128-wide GCN layers, shared 128-wide mutation-aware site MLP and output head. Graphs include contacts, adjacent residues and self-loops with symmetric degree normalization. Head scalars add 3D distance/10. Architectures and width were preserved; ordered single-effect inputs were replaced by their symmetric sum and absolute difference.')
 P(f"Direct inspection of the preserved classes gives {specs['M1']['nominal_trainable_parameters']:,} trainable M1 parameters and {specs['M2']['nominal_trainable_parameters']:,} trainable M2 parameters. The 650M encoder remains frozen. Exact layer shapes are supplied in model_specifications.json; the original models differ in capacity as well as structural inputs.")
 P('Singles-only normalization and removal of the fitted double-mutant reference prevent target leakage. Mutation-order invariance was tested. M1 linear factoring and sparse disconnected M2 graph execution were checked against the original class computations for both predictions and gradients. These changes improve execution efficiency without replacing the network mathematics.')
 page('3. Nested training and robustness protocol')
 P('Both protocols use five outer folds and three inner folds. Assignment greedily balances pair counts at the required group level. In protein evaluation all assays of a UniProt protein remain together. In robustness evaluation both levels hold out entire similarity components. No outer outcomes select hyperparameters, training duration or checkpoints.')
 table(['Setting','Predefined value'],[['Candidate 0','Adam LR 0.001; dropout 0; weight decay 0'],['Candidate 1','Adam LR 0.001; dropout 0.1; weight decay 0.0001'],['Candidate 2','Adam LR 0.0003; dropout 0.3; weight decay 0.001'],['Model selection','Protein-macro interaction Spearman; inner-fold scores weighted by eligible proteins; candidate ties within 0.0001 favor earlier candidate.'],['Stopping','Maximum 40 epochs; patience 5; improvement threshold 0.0001. Final epoch count is rounded median of the selected candidate best inner epochs.'],['Seeds and batches','Selection seed 1729 + 100 x outer fold + inner fold; final seeds 0,1,2. M1 batch 4,096; M2 batch 2,048. Hidden width 128.'],['Similarity grouping','MMseqs2 at identity 0.30 and coverage 0.80, plus shorter-domain overlap >=40 amino acids at E <=0.001; connected components over all assay sequences.'],['Execution','CPU FP32; 2 Torch threads per fold worker; up to 4 independent outer-fold workers. Checkpoint replay uses standard original-class inference.']],[110,375])
 sel=pd.DataFrame(selection);P(f"All 20 selected searches contain nine inner fits each. {int(sel.inner_epoch_cap_hits.sum())} of {int(sel.inner_fits.sum())} inner fits reached the fixed epoch cap; complete epoch histories and selection decisions are provided. Reaching the cap does not justify retrospective retuning on held-out results.")
 P('Persistence order per seed: checkpoint immediately after fit; held-out labels and predictions; configuration, history and metrics; reopen and check all files; reload and replay the checkpoint; publish the verified package; update and publish progress. Resumption checks actual artifacts and hashes before skipping. Verified recovered fits were reused.')
 page('4. Protein-grouped results')
 pic('protein_performance.png')
 for agg in ['macro_protein','macro_assay','pooled']:
  H(agg.replace('_',' ').title());t=by['protein'].query('aggregation==@agg');table(['Model']+[LABELS[k] for k in LABELS],[[m]+[fmt(t[t.model==m][k].mean(),6) for k in LABELS] for m in ['M0','M1','M2']],[42,88,88,88,88,91],compact=True)
 P('All values average independently evaluated seed metrics, except deterministic M0. Interaction and effect RMSE are equal because their prediction errors differ only by the same measured additive term. The two Spearman measures answer different questions.')
 page('5. Sequence-cluster-disjoint results')
 pic('cluster_performance.png')
 for agg in ['macro_protein','macro_assay','pooled']:
  H(agg.replace('_',' ').title());t=by['cluster'].query('aggregation==@agg');table(['Model']+[LABELS[k] for k in LABELS],[[m]+[fmt(t[t.model==m][k].mean(),6) for k in LABELS] for m in ['M0','M1','M2']],[42,88,88,88,88,91],compact=True)
 P('Cluster-disjoint scores come from newly trained models with cluster-grouped inner selection. The sequence identity/domain rule reduces detected similarity across folds; it cannot exclude all remote homology. Fold composition differs from protein grouping, so protocol differences are sensitivity evidence rather than a randomized causal effect of homolog overlap.')
 page('6. Individual seeds and paired uncertainty')
 for p in PROTOCOLS:
  H(p.capitalize()+' holdout: protein-macro metrics');t=by[p].query("aggregation=='macro_protein' and model!='M0'");table(['Model','Seed']+[LABELS[k] for k in PRIMARY],[[r.model,int(r.seed)]+[fmt(r[k]) for k in PRIMARY] for _,r in t.iterrows()],[48,42,135,135,125])
 P('Uncertainty uses 2,000 paired whole-group percentile bootstrap draws (seed 2026). Resample whole proteins for protein evaluation and whole sequence components for robustness; retain all assays and multiplicity within each selected unit. Group metrics are averaged across final seeds before resampling. Undefined group metrics are omitted with eligibility counts. The paired interval compares identical eligible M1/M2 groups.')
 P('These intervals condition on the saved out-of-fold fits; they do not include the uncertainty of refitting the complete training pipeline on a resampled dataset. Between-seed standard deviations are supplied separately and are not confidence intervals.')
 page('7. Paired comparison and protein heterogeneity')
 pic('paired_differences.png')
 for p in PROTOCOLS:
  H(p.capitalize()+' holdout');P(ci_text(p))
 pic('per_protein_comparison.png',width=6.2*inch)
 P('Positive M2-minus-M1 values favor M2 for correlation/AUROC; negative values favor M2 for RMSE. An interval containing zero does not establish a difference. Per-protein and per-assay tables, geometry slices and alternative strong-epistasis thresholds are included to inspect heterogeneity; they do not replace primary whole-cohort outcomes.')
 page('8. Improvement beyond the additive baseline')
 P('Paired whole-group intervals compare each trained model against the original untrained additive M0 on identical held-out pairs. The table uses protein-macro interaction metrics and seed-averaged trained-model group scores. M0 has no training-seed variation; its uncertainty here arises from resampling proteins or similarity components.')
 for p in PROTOCOLS:
  H(p.capitalize()+' holdout: trained model minus M0');b=baseline_ci.query("protocol==@p and aggregation=='macro_protein' and metric in ['epi_auroc','epi_rmse']");table(['Model','Metric','Difference','95% paired CI'],[[r.compared_model,LABELS[r.metric],fmt(r.compared_minus_reference),f'[{fmt(r.ci_low)}, {fmt(r.ci_high)}]'] for _,r in b.iterrows()],[50,150,90,195])
 P('Positive AUROC differences and negative RMSE differences favor the trained model. M0 interaction Spearman is undefined, so a Spearman difference against M0 is not estimated. All secondary effect and assay-macro comparisons are supplied in paired_comparisons_with_M0.csv. These intervals retain the same conditional-on-fits scope and do not adjust for multiple secondary comparisons.')
 if have_ablations:
  page('9. Predefined structure-channel diagnostics')
  P('Both channel-removal diagnostics retain the original M2 architecture and width, the exact matched cohort and protein-grouped splits, identical inner search candidates, and final seeds 0, 1 and 2. no_contacts removes 3D contact edges while retaining sequence neighbors, self-loops and direct pair distance. no_distance zeros only the direct 3D-distance scalar, retaining the original contact GCN. They run only after all required primary and cluster experiments have been verified.')
  t=ab.query("aggregation=='macro_protein'");table(['Model']+[LABELS[k] for k in PRIMARY],[[model]+[fmt(t[t.model==model][k].mean()) for k in PRIMARY] for model in ['M2','M2_no_contacts','M2_no_distance']],[110,125,125,125])
  c=aci.query("aggregation=='macro_protein' and metric in ['epi_spearman','epi_auroc','epi_rmse']");table(['Removed channel','Metric','Ablated - full','Paired 95% CI'],[[r.ablation,LABELS[r.metric],fmt(r.ablated_minus_full_M2),f'[{fmt(r.ci_low)}, {fmt(r.ci_high)}]'] for _,r in c.iterrows()],[88,130,90,177])
  P('Negative Spearman/AUROC differences or positive RMSE differences favor full M2. Intervals use the same 2,000-draw, whole-protein paired bootstrap conditional on saved fits. These secondary comparisons are unadjusted for multiplicity. All 30 actual ablation checkpoints pass original-class replay; their inner/outer assignments match primary M2. Seed-level, assay-macro and effect metrics are supplied in the ablation package.')
  if ((c.ci_low<=0)&(c.ci_high>=0)).all():P('All six primary channel-removal intervals include zero: neither individual removal establishes a metric change. Each removal retains the other structural channel; a jointly structure-free M2 was not trained.')
 page(('10' if have_ablations else '9')+'. Interpretation, limitations and reproducibility')
 P('Inference is conditional on measured single-mutant effects for a held-out protein. No zero-shot or singles-free prediction claim follows. Naive additive-scale epistasis can reflect assay nonlinearities and does not uniquely identify physical residue-residue interaction energies. Population selection requires measurable singles and suitable structural coverage; generalization beyond these 45 proteins remains uncertain.')
 P('Both learned models receive measured single effects as inputs. Improvement over the untrained additive M0 does not by itself isolate the value of ESM features from a learned nonlinear dependence on singles. A trained singles-only nonlinear control was not part of this preserved primary protocol, so no sequence-embedding-specific causal contribution is claimed. Verified residue identity mapping does not validate every 3D contact; the preserved graph has no explicit structure-confidence weighting.')
 P('M1 and M2 differ in architecture as well as structural information. Their fair matched-data comparison measures complete model performance, not a causal effect of structure alone. '+('The additional within-M2 channel ablations are limited to protein-grouped holdout; geometry slices remain descriptive and do not replace retraining.' if have_ablations else 'Optional retrained structure-removal ablations were not run; descriptive contact/distance slices are not ablations.')+' No unperformed experiment is assigned a score.')
 P('All final scores require saved predictions. Earlier console-only M1 means remain provisional historical records, not independent evidence. Hyperparameters were fixed before final outer evaluation; no new search was added to optimize reported held-out results.')
 H('Reproduce and inspect');P('Restore the recovered configuration, canonical inputs, embedding cache and revised code. Install the pinned dependencies. Run the tests and run_project.py with the configured persistent destination. The progress manifest identifies verified seed packages. verify_all.py replays all 60 original-class checkpoints, checks complete OOF keys and group separation, confirms identical M1/M2 splits, and regenerates byte-identical evaluation tables. make_final_outputs.py requires that verification before creating this report and chart sources.')
 H('Files');P('BS6204_M1_Protein_Results.zip and BS6204_M2_Protein_Results.zip contain actual checkpoints, predictions and histories. BS6204_Cluster_Results.zip contains both robustness models. BS6204_Final_Results.zip contains exact seed/summary metrics, paired intervals, per-group tables, diagnostics, editable SVG/PDF figures, CSV chart sources, presentation content and verification evidence. BS6204_Revised_Code.zip contains source and reproducibility records. Large public encoder weights are referenced with checksums; reusable frozen features are supplied separately.')
 H('Primary sources');P('Original project: https://github.com/Cheshta-C/bs6204-epistasis (pinned original commit above). Exact ProteinGym, ESM-2 and MMseqs2 source URLs and checksums are in downloads/public_resource_manifest.json and prepare_from_public.py. The embedding manifest records model/layer and sequence hashes. MMseqs2 commands, executable version and accepted edges are in clustering_manifest.json and the clustering audit. The exact small public source archives are also supplied.')
 def footer(canvas,doc):
  canvas.setStrokeColor(colors.HexColor('#b5c9d4'));canvas.line(42,39,570,39);canvas.setFont('BSRegular',8);canvas.setFillColor(colors.HexColor('#526472'));canvas.drawString(42,26,'BS6204 | Validated variant-pair epistasis');canvas.drawRightString(570,26,str(doc.page))
 pdf=BASE/'durable/BS6204_Final_Scientific_Report.pdf';SimpleDocTemplate(str(pdf),pagesize=(612,792),leftMargin=42,rightMargin=42,topMargin=40,bottomMargin=50,title='Collocating or Interacting? Deep Learning of Variant-Pair Epistasis',author='BS6204 reproducibility study').build(story,onFirstPage=footer,onLaterPages=footer)
 json_file({'requires':'60 primary plus all executed diagnostic checkpoints verified and persisted','report_sha256':sha(pdf),'figure_sources':True,'presentation_content':True,'source_verification':v,'additional_structural_verification':av if have_ablations else None,'saved_record_audit':record_audit,'authoring_script_sha256':sha(Path(__file__))},out/'final_generation_manifest.json');print('GENERATED',pdf,flush=True)
if __name__=='__main__':main()

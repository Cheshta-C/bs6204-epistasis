"""Incremental presentation deliverable from independently replayed protein results."""
import sys,json
from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,archive,publish
K=['epi_spearman','epi_auroc','epi_rmse'];N={'epi_spearman':'Interaction Spearman','epi_auroc':'Interaction AUROC','epi_rmse':'Interaction RMSE'}
def f(x):return f'{x:.6f}' if pd.notna(x) else 'undefined'
def main():
 w=BASE/'artifacts';v=json.load(open(w/'verification/recovered_primary_verification.json'));assert v['restored_primary_checkpoints_verified']==30 and v['primary_metrics_recomputed_csv_byte_identical'];out=w/'protein_presentation';out.mkdir(exist_ok=True);seed=pd.read_csv(w/'evaluation/protein/metrics_by_seed.csv');t=seed.query("aggregation=='macro_protein'");means=t.groupby('model')[K].mean();ci=pd.read_csv(w/'evaluation/protein/paired_confidence_intervals.csv').query("aggregation=='macro_protein'");means.to_csv(out/'protein_macro_chart_source.csv');t.to_csv(out/'individual_seeds.csv',index=False);ci.to_csv(out/'paired_CI_chart_source.csv',index=False)
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False});palette={'M0':'#8592a3','M1':'#167d9a','M2':'#df8241'}
 fig,axs=plt.subplots(1,3,figsize=(10.7,3.5))
 for ax,k in zip(axs,K):
  for i,model in enumerate(['M0','M1','M2']):
   y=means.loc[model,k]
   if model=='M0':
    if np.isfinite(y):ax.plot(i,y,'o',color=palette[model],ms=7)
    else:ax.text(i,.05,'undefined',rotation=90,va='bottom',ha='center',transform=ax.get_xaxis_transform(),color=palette[model])
   else:
    r=ci[ci.metric==k].iloc[0];ax.vlines(i,r[model+'_ci_low'],r[model+'_ci_high'],color=palette[model],lw=1.8);ax.plot(i,y,'o',color=palette[model],ms=7)
  ax.set(title=N[k],xticks=[0,1,2],xticklabels=['M0','M1','M2'],xlim=(-.4,2.4));ax.grid(axis='y',alpha=.2)
 fig.suptitle('Protein-grouped nested validation | 221,340 pairs / 45 proteins',fontweight='bold');fig.text(.5,.005,'Points: mean seed metrics. M1/M2 intervals: paired whole-protein bootstrap, conditional on saved fits.',ha='center',fontsize=8);fig.tight_layout(rect=(0,.05,1,.94))
 for ext in ['svg','png']:fig.savefig(out/f'protein_performance.{ext}',dpi=220,bbox_inches='tight')
 plt.close(fig);fig,axs=plt.subplots(1,3,figsize=(10.7,3.2))
 for ax,k in zip(axs,K):
  r=ci[ci.metric==k].iloc[0];ax.hlines(0,r.ci_low,r.ci_high,color='#167d9a',lw=2);ax.plot(r.M2_minus_M1,0,'o',color='#167d9a');ax.axvline(0,color='#888',lw=1);ax.set(title=N[k],xlabel='M2 minus M1',yticks=[])
 fig.suptitle('Paired protein-level differences | 95% percentile bootstrap intervals',fontweight='bold');fig.tight_layout()
 for ext in ['svg','png']:fig.savefig(out/f'paired_differences.{ext}',dpi=220,bbox_inches='tight')
 plt.close(fig)
 selections=[]
 for model in ['M1','M2']:
  for fold in range(5):selections.append(dict(model=model,fold=fold,**json.load(open(w/f'runs/durable_v2/protein/{model}/fold_{fold}/selection.json'))))
 pd.DataFrame(selections).to_csv(out/'actual_outer_fold_selections.csv',index=False)
 table='| Model | Interaction Spearman | Interaction AUROC | Interaction RMSE |\n|---|---:|---:|---:|\n'+'\n'.join('| '+m+' | '+' | '.join(f(means.loc[m,k]) for k in K)+' |' for m in ['M0','M1','M2'])
 seedtable='| Model | Seed | Interaction Spearman | Interaction AUROC | Interaction RMSE |\n|---|---:|---:|---:|---:|\n'+'\n'.join('| '+r.model+' | '+str(int(r.seed))+' | '+' | '.join(f(r[k]) for k in K)+' |' for _,r in t[t.model!='M0'].iterrows())
 intervals='\n'.join('- '+N[r.metric]+': M2 minus M1 = '+f(r.M2_minus_M1)+'; 95% CI ['+f(r.ci_low)+', '+f(r.ci_high)+'].' for _,r in ci[ci.metric.isin(K)].iterrows())
 blocks=[]
 def slide(title,content,visual,takeaway,speaker):blocks.append('## '+title+'\n\n**Content**\n\n'+content+'\n\n**Suggested visual:** '+visual+'\n\n**Main takeaway:** '+takeaway+'\n\n**Speaker explanation:** '+speaker+'\n')
 slide('1. M1: predicting epistasis from sequence','- Frozen ESM-2 650M, layer 33; 1,280 features per residue.\n- Learned WT/mutant amino-acid embeddings; shared two-layer site MLP, width 128.\n- Sum both site vectors; add zA+zB, |zA-zB| and scaled sequence distance.\n- A 128-wide head predicts epsilon = zAB-zA-zB.','Four blocks: frozen ESM -> shared mutation-site encoders -> sum + symmetric scalars -> epistasis.','The trained head predicts nonadditivity beyond measured single effects.','ESM is frozen. The model learns how the two specified substitutions and their sequence contexts predict the departure from an additive baseline.')
 slide('2. M2: the original structure-informed GCN','- Same frozen ESM-2 650M features.\n- Projection to 128; two GCN layers of width 128.\n- Contact edges, adjacent residues and self-loops; symmetric degree normalization.\n- Shared mutation-aware site encoder; sum the two sites.\n- Symmetric single-effect features, sequence distance and direct 3D distance.','ESM residue nodes -> two contact-graph layers -> mutation-site encoders -> summed pair head.','M2 incorporates graph context and direct spatial distance.','Residues exchange information along the protein graph before the mutation sites are scored. M2 also changes architecture, so the M1-M2 comparison alone cannot isolate a causal effect of structure.')
 slide('3. Training and nested validation','- Matched original cohort: 221,340 pairs, 47 assays and 45 proteins.\n- Five outer folds; three inner folds; all assays of one protein stay together.\n- Three fixed learning-rate/dropout/weight-decay candidates.\n- Inner protein-macro interaction Spearman selects settings and stopping.\n- Epoch cap 40, patience 5; final epochs are the rounded median of selected inner best epochs.\n- Final seeds 0, 1 and 2; M1 batch 4,096; M2 batch 2,048.\n- Singles-only mean and sample SD; no fitted double-mutant reference.','Nested fold diagram; actual_outer_fold_selections.csv contains the selected configurations.','Outer held-out outcomes do not tune the models.','All preprocessing uses the measured singles for each assay. No held-out double-mutant labels fit normalization or a reference curve. This assumes singles are available for a new protein.')
 slide('4. Evaluating interaction prediction','- Primary: interaction Spearman, strong-epistasis AUROC and interaction RMSE.\n- Strong epistasis: |true epsilon| > 1; AUROC ranking score |predicted epsilon|.\n- Secondary: double-mutant RMSE/Spearman; assay-macro, pooled and per-protein metrics.\n- M0 predicts zero interaction and zA+zB for the double mutant.','Three metric cards; show epsilon separately from reconstructed zAB.','Double-mutant correlation must not replace interaction correlation.','Spearman measures interaction ranking, AUROC ranks strong epistasis, and RMSE measures interaction magnitude error. A constant-zero M0 has undefined interaction Spearman, not zero correlation.')
 slide('5. Actual protein-grouped held-out performance',table+'\n\n'+seedtable,'protein_performance.svg; exact source protein_macro_chart_source.csv.','Both learned models improve on additive M0 in interaction RMSE.','Every seed has complete held-out predictions for all 221,340 pairs. These are means of independently evaluated seed metrics, not an ensemble of averaged predictions. RMSE for interaction and reconstructed double-mutant effect is equal by algebra.')
 slide('6. Does M2 improve over M1?',intervals,'paired_differences.svg; paired_CI_chart_source.csv.','The paired intervals do not establish an M2 improvement.','M2 has slightly higher interaction Spearman as a point estimate, but lower AUROC and higher RMSE. Every primary paired interval includes zero. The intervals resample whole proteins and condition on these trained fits; they do not refit the training pipeline for every bootstrap draw.')
 slide('7. Sequence-cluster robustness','- Separate protocol: 39 independently verified MMseqs2 components across the 45 proteins.\n- Identity 30%, coverage 80%, plus the defined shorter-domain overlap rule.\n- Whole components remain together in both outer and inner folds.\n- Cluster-model training is in progress; no cluster performance number is claimed in this incremental package.','Leave numerical cluster results off the slide until the verified cluster package is delivered.','Protein-disjoint validation does not guarantee sequence-cluster disjointness.','This robustness experiment fits separate models with proper inner selection. It tests transfer across detected sequence-similarity groups, not absolute absence of remote homology.')
 slide('8. Structural interpretation and limitations','- Same training/evaluation pairs and folds for M1 and M2.\n- M1-M2 differences combine architecture and structural information.\n- Per-protein and near/far contact diagnostics are descriptive.\n- Measured singles are required; no zero-shot claim.\n- Naive epistasis depends on assay scale and may include global nonlinear effects.\n- Structural channel-removal ablations have no reported scores until trained and verified.','Per-protein table and paired intervals; avoid a causal structure-benefit claim.','Interpret validated statistical epistasis prediction within this cohort.','We predict departures from additivity, not physical interaction energies. A favorable effect-score metric or a contact-stratified association cannot independently establish accurate or causal residue-pair interaction prediction.')
 (out/'BS6204_Protein_Presentation_Content.md').write_text('# Original BS6204 protein-epistasis project\n\nComplete verified protein-holdout presentation content. The separate cluster experiments remain in progress.\n\n'+'\n'.join(blocks))
 files=[(p,p.name) for p in out.iterdir() if p.is_file()];files += [(p,'verified_metrics/'+p.name) for p in (w/'evaluation/protein').glob('*') if p.is_file()];files += [(w/'verification/recovered_primary_verification.json','recovered_primary_verification.json'),(w/'verification/recovered_primary_checkpoint_replay.csv','recovered_primary_checkpoint_replay.csv')];archive(DURABLE/'BS6204_Protein_Presentation_Content.zip',files);publish(DURABLE/'BS6204_Protein_Presentation_Content.zip')
if __name__=='__main__':main()

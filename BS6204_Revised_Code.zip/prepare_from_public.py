"""Recover public resources without overwriting verified reusable inputs.

Default downloads the small raw sources. --rebuild-inputs replays original selection,
corrected normalization and original structure features, then verifies the cohort.
--regenerate-embeddings explicitly requests the expensive ESM-2 computation.
Restore the supplied prepared archives instead whenever they remain valid.
"""
import argparse,json,os,sys,urllib.request,zipfile,subprocess,shutil
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE
from atomic_io import sha,json_file,csv_file
SOURCES={
 'DMS_ProteinGym_substitutions.zip':('https://marks.hms.harvard.edu/proteingym/ProteinGym_v1.3/DMS_ProteinGym_substitutions.zip','3a83766254ac9ac9984ec25cb73c6e010ea4418f5e35f143933e6b6e6473b921'),
 'ProteinGym_AF2_structures.zip':('https://marks.hms.harvard.edu/proteingym/ProteinGym_v1.3/ProteinGym_AF2_structures.zip','ed8611bf12cfb840ea1c2561be36254901008610a49b1be475e917b6c5d6d56a'),
 'DMS_substitutions.csv':('https://raw.githubusercontent.com/OATML-Markslab/ProteinGym/144fe22b07dfaeec2b366f2346203a9838a55b4c/reference_files/DMS_substitutions.csv','a8f498011532a74aa9fe556a50555a75e928c5837d19c06a87592ae04049b308'),
 'mmseqs.tar.gz':('https://mmseqs.com/latest/mmseqs-linux-avx2.tar.gz','451f8cd15219ebaae58054c163dec54689596ff8538dc0a80edabcbf544dd10b'),
 'esm2_t33_650M_UR50D.pt':('https://dl.fbaipublicfiles.com/fair-esm/models/esm2_t33_650M_UR50D.pt','ea9d0522b335a8778dea6535a65301f10208dece28cd5865482b0b1fc446168c'),
 'esm2_t33_650M_UR50D-contact-regression.pt':('https://dl.fbaipublicfiles.com/fair-esm/regression/esm2_t33_650M_UR50D-contact-regression.pt','8ffe6edbd4173dc8d45c2cd5cb27d43aad77ec26b4c768200c58ae1f96693575')}
def download(name,folder):
 folder.mkdir(parents=True,exist_ok=True);path=folder/name;url,expected=SOURCES[name]
 if path.exists():
  if sha(path)!=expected:raise ValueError('Existing public resource hash mismatch: '+str(path))
  print('REUSE',name,flush=True);return path
 tmp=path.with_suffix(path.suffix+'.download');req=urllib.request.Request(url,headers={'User-Agent':'BS6204-reproducibility/1.0'})
 with urllib.request.urlopen(req,timeout=120) as inp,open(tmp,'wb') as out:shutil.copyfileobj(inp,out,1024*1024);out.flush();os.fsync(out.fileno())
 if sha(tmp)!=expected:raise ValueError('Public source bytes changed; refuse silent substitution: '+url)
 os.replace(tmp,path);return path
def run(*args):subprocess.run([sys.executable,*map(str,args)],check=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--rebuild-inputs',action='store_true');p.add_argument('--regenerate-embeddings',action='store_true');a=p.parse_args();w=BASE/'artifacts';raw=w/'downloads'
 for n in list(SOURCES)[:4]:download(n,raw)
 json_file({n:{'source_url':u,'sha256':s} for n,(u,s) in SOURCES.items()},raw/'public_resource_manifest.json')
 if a.rebuild_inputs:
  data=w/'data';data.mkdir(exist_ok=True)
  for n in list(SOURCES)[:2]:
   with zipfile.ZipFile(raw/n) as z:
    for item in z.infolist():
     target=(data/item.filename).resolve();assert target.is_relative_to(data.resolve()),'Unsafe archive path'
    z.extractall(data)
  inputs=w/'inputs'
  if not (inputs/'pairs.csv').exists():run(ROOT/'src/build_pairs.py',data/'DMS_ProteinGym_substitutions',raw/'DMS_substitutions.csv','--out',inputs)
  d=pd.read_csv(inputs/'pairs.csv');assert (len(d),d.assay.nunique(),d.UniProt_ID.nunique())==(235355,48,46)
  original=w/'original'
  if not (original/'pairs.csv').exists():run(ROOT/'historical/404f8bb/src/build_pairs.py',data/'DMS_ProteinGym_substitutions',raw/'DMS_substitutions.csv','--out',original)
  if not (inputs/'pairs_struct.csv').exists():
   temp=w/'structure_rebuild';temp.mkdir(exist_ok=True);run(ROOT/'src/structure_features.py',inputs/'pairs.csv',inputs/'sequences.csv',data/'ProteinGym_AF2_structures','--exclude-protein','A4_HUMAN','--out-pairs',temp/'pairs_3d.csv','--out-contacts',inputs/'contacts.npz','--out-report',inputs/'structure_mapping.csv')
   d=pd.read_csv(temp/'pairs_3d.csv');d=d[d.dist_3d.notna() & (d.UniProt_ID!='A4_HUMAN')];csv_file(d,inputs/'pairs_struct.csv')
  assert sha(inputs/'pairs_struct.csv')=='4277f5a8631d0b4be22e431ff3bd02c3c4870c30a488b3af19f65a07ad9cb459'
 if a.regenerate_embeddings:
  cache=w/'caches/wt_emb_650.pt'
  if cache.exists():print('REUSE existing embedding cache; audit before fitting',flush=True)
  else:
   for n in list(SOURCES)[4:]:download(n,w/'models')
   run(ROOT/'src/regenerate_embeddings.py',w/'inputs/sequences.csv',w/'models/esm2_t33_650M_UR50D.pt',cache)
 print('Public resources verified. Run src/prepare_audit.py after restoring the recovered records and embedding cache; this audit also independently reruns MMseqs2.',flush=True)
if __name__=='__main__':main()

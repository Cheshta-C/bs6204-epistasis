"""Run required phases in priority order; no next phase before verified exports."""
import os,sys,json,time,subprocess,zipfile
from pathlib import Path
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='2'
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,MANIFEST,check,publish,archive
from evaluate_results import evaluate
from atomic_io import json_file,sha
from nested_runner import signature
WORK=BASE/'artifacts'

def package_name(protocol,model):
 return 'BS6204_M1_Protein_Results.zip' if protocol=='protein' and model=='M1' else ('BS6204_M2_Protein_Results.zip' if protocol=='protein' else 'BS6204_Cluster_Results.zip')

def phase_is_verified(protocol,model):
 m=json.load(open(MANIFEST));name=package_name(protocol,model);receipt=m.get('artifacts',{}).get(name);path=DURABLE/name
 if not receipt or not path.is_file() or sha(path)!=receipt['sha256']:return False
 try:
  with zipfile.ZipFile(path) as z:status=json.loads(z.read('PACKAGE_STATUS.json'))
  if status['protocol']!=protocol or model not in status['completed_models']:return False
  sig=signature(WORK,ROOT/'configs/nested_v1.json',model,protocol,'full')
  for f in range(5):
   fo=WORK/f'runs/durable_v2/{protocol}/{model}/fold_{f}'
   if json.load(open(fo/'COMPLETE.json'))['signature']!=sig:return False
   for seed in [0,1,2]:
    r=m['jobs'][f'{protocol}/{model}/fold_{f}/seed_{seed}'];job=fo/f'seed_{seed}'
    if not (r.get('persisted') and r.get('verified') and r.get('inference_verified') and r['signature']==sig):return False
    if not all((job/n).is_file() and sha(job/n)==s for n,s in r['files'].items()):return False
    proof=json.load(open(job/'verification.json'))
    if proof['signature']!=sig or not proof['inference_verified'] or not all(proof['files'].get(n)==s for n,s in r['files'].items()):return False
  return True
 except (OSError,ValueError,KeyError,zipfile.BadZipFile):return False

def phase(protocol,model):
 if phase_is_verified(protocol,model):print('REUSE VERIFIED PHASE PACKAGE',protocol,model,flush=True);return
 check();logs=WORK/'logs';todo=list(range(5));running={};handles={};max_workers=4
 while todo or running:
  check()
  while todo and len(running)<max_workers:
   f=todo.pop(0);log=open(logs/f'{protocol}-{model}-fold{f}.log','a');cmd=[sys.executable,'-u',str(ROOT/'src/nested_runner.py'),'--work',str(WORK),'--protocol',protocol,'--model',model,'--fold',str(f),'--threads','2'];proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy());running[f]=proc;handles[f]=log;print('START',protocol,model,f,flush=True)
  for f,proc in list(running.items()):
   code=proc.poll()
   if code is not None:
    handles.pop(f).close();running.pop(f);print('EXIT',protocol,model,f,code,flush=True)
    if code:
     for x in running.values():x.terminate()
     raise RuntimeError(f'Job failed: {protocol}/{model}/{f}; see logs. No further work started.')
  if running:time.sleep(2)
 models=['M1'] if model=='M1' else ['M1','M2'];out=evaluate(WORK,protocol,models,WORK/f'evaluation/{protocol}')
 name=package_name(protocol,model)
 files=[]
 include_models=[model] if protocol=='protein' else models
 for mm in include_models:
  r=WORK/f'runs/durable_v2/{protocol}/{mm}'
  files += [(f,'artifacts/'+str(f.relative_to(WORK))) for f in r.rglob('*') if f.is_file()]
 files += [(f,'artifacts/'+str(f.relative_to(WORK))) for f in out.rglob('*') if f.is_file()]
 status=DURABLE/'PACKAGE_STATUS.json';json_file({'protocol':protocol,'completed_models':models,'all_requested_models_complete':model=='M2','source':'actual checkpoints and saved predictions'},status);files.append((status,'PACKAGE_STATUS.json'));z=DURABLE/name;archive(z,files);publish(z);print('PHASE COMPLETE',protocol,model,flush=True)

def main():
 for protocol,model in [('protein','M1'),('protein','M2'),('cluster','M1'),('cluster','M2')]:phase(protocol,model)
 subprocess.run([sys.executable,str(ROOT/'src/verify_all.py'),str(WORK)],check=True)
 print('ALL REQUIRED SCIENTIFIC RUNS VERIFIED',flush=True)
if __name__=='__main__':main()

"""All writers serialize exports. A failed or uncertain save stops scientific work."""
import os,json,subprocess,sys,zipfile,fcntl,datetime
from pathlib import Path
from atomic_io import sha,json_file
BASE=Path(os.environ.get('BS6204_WORKSPACE',Path(__file__).resolve().parents[2])).resolve()
DURABLE=BASE/'durable';MANIFEST=DURABLE/'BS6204_Progress_Manifest.json';REGISTRY=DURABLE/'export_registry.json';ABORT=BASE/'artifacts/PERSISTENCE_FAILED'
def check():
 if ABORT.exists():raise RuntimeError('Persistent storage failure: halt before more computation: '+ABORT.read_text())
def archive(path,files):
 import tempfile
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.building')
 with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
  for file,arcname in files:
   if Path(file).is_file() and not str(file).endswith('.partial'):
    if Path(file).name=='verification.json':
     record=json.load(open(file))
     if isinstance(record.get('files'),dict):record['files']={n:s for n,s in record['files'].items() if not n.endswith('.partial')}
     z.writestr(str(arcname),json.dumps(record,indent=2,allow_nan=False)+'\n')
    else:z.write(file,str(arcname))
 with zipfile.ZipFile(tmp) as z:
  if z.testzip() is not None:raise ValueError('ZIP integrity failure')
 os.replace(tmp,path)
 return sha(path)
def _send(path,registry):
 path=Path(path).resolve();key=path.name;old=registry.get(key);item={'local_path':str(path),'purpose':'replace_library_file' if old else 'create_library_file'}
 if old:
  item['library_file_id']=old['library_file_id']
  if old.get('current_version_number') is not None:item['expected_current_version']=old['current_version_number']
 else:item['library_artifact_type']='report' if path.suffix.lower()=='.pdf' else 'other'
 helper=BASE/'.persistent_export_v2/run_upload_with_timeout.py'
 r=subprocess.run([sys.executable,str(helper)],input=json.dumps({'uploads':[item]}),text=True,capture_output=True)
 data=None
 for line in r.stdout.splitlines():
  if line.startswith('{"results"'):data=json.loads(line)
 if r.returncode or not data or len(data.get('results',[]))!=1 or data['results'][0].get('status')!='succeeded':
  raise RuntimeError('Persistent export failed or uncertain; no automatic retry. '+r.stdout[-1800:]+r.stderr[-500:])
 result=data['results'][0]
 if not result.get('library_file_id') or not result.get('local_metadata_applied'):raise RuntimeError('Missing confirmed destination/metadata')
 registry[key]={'library_file_id':result['library_file_id'],'current_version_number':result.get('current_version_number'),'sha256':sha(path),'bytes':path.stat().st_size,'url':'https://chatgpt.com/library?file_id='+result['library_file_id']+'&account_id=personal'}
 json_file(registry,REGISTRY);print('PERSISTED',key,result['library_file_id'],flush=True);return registry[key]
def publish(path,job=None,job_record=None,selection=None):
 check();DURABLE.mkdir(exist_ok=True)
 with open(DURABLE/'export.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  check()
  try:
   registry=json.load(open(REGISTRY));receipt=_send(path,registry);m=json.load(open(MANIFEST));m['artifacts'][Path(path).name]=receipt;m['updated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
   if job:
    record=dict(job_record or {})
    if 'files' in record:record['files']={n:s for n,s in record['files'].items() if not n.endswith('.partial')}
    record.update(status='verified_and_persisted',verified=True,persisted=True,artifact=receipt);m['jobs'][job]=record
    m['verified_persisted_seed_counts']={prefix:sum(bool(v.get('verified') and v.get('persisted')) for k,v in m['jobs'].items() if k.startswith(prefix+'/')) for prefix in sorted(set('/'.join(k.split('/')[:2]) for k in m['jobs']))}
    m['status']='running_'+'_'.join(job.split('/')[:2])
   if selection:m.setdefault('selections',{})[selection]={'verified':True,'persisted':True,'artifact':receipt}
   json_file(m,MANIFEST);_send(MANIFEST,registry)
   return receipt
  except Exception as e:
   ABORT.write_text(str(e));raise

import argparse,json,hashlib
from pathlib import Path
import pandas as pd,torch,esm
from atomic_io import torch_file,json_file
from persistence import publish,archive,check,BASE

def main():
 p=argparse.ArgumentParser();p.add_argument('sequences');p.add_argument('weights');p.add_argument('output');a=p.parse_args();torch.set_num_threads(4)
 seq=pd.read_csv(a.sequences);out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True);partial=out.with_suffix('.partial.pt');emb=torch.load(partial,weights_only=True) if partial.exists() else {}
 with torch.serialization.safe_globals([argparse.Namespace]):model,alphabet=esm.pretrained.load_model_and_alphabet_local(a.weights)
 model.eval().requires_grad_(False);bc=alphabet.get_batch_converter();meta={'model':'esm2_t33_650M_UR50D','layer':33,'dtype':'float32','truncation':False,'sequences':{}}
 with torch.inference_mode():
  for i,r in enumerate(seq.itertuples()):
   check();meta['sequences'][r.assay]=hashlib.sha256(r.target_seq.encode()).hexdigest()
   if r.assay not in emb:
    _,_,tokens=bc([(r.assay,r.target_seq)]);emb[r.assay]=model(tokens,repr_layers=[33],return_contacts=False)['representations'][33][0,1:len(r.target_seq)+1].cpu().contiguous();torch_file(emb,partial)
   assert emb[r.assay].shape==(len(r.target_seq),1280) and torch.isfinite(emb[r.assay]).all();print(r.assay,len(r.target_seq),flush=True)
   if (i+1)%12==0:
    json_file(meta,out.with_suffix('.json'));z=BASE/'durable/BS6204_Embedding_Cache.zip';archive(z,[(partial,'caches/wt_emb_650.partial.pt'),(out.with_suffix('.json'),'caches/provenance.json')]);publish(z)
 torch_file(emb,out);json_file(meta,out.with_suffix('.json'));z=BASE/'durable/BS6204_Embedding_Cache.zip';archive(z,[(out,'caches/wt_emb_650.pt'),(out.with_suffix('.json'),'caches/wt_emb_650.json')]);publish(z);partial.unlink(missing_ok=True)
if __name__=='__main__':main()

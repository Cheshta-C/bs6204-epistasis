import numpy as np,pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score
KEY=['assay','mutant']
METRICS=['epi_spearman','epi_auroc','epi_rmse','z_spearman','z_rmse']
def spear(y,p):
 return float(spearmanr(y,p).statistic) if len(y)>=3 and np.ptp(y)>0 and np.ptp(p)>0 else np.nan
def score(g,threshold=1.):
 y=np.asarray(g.epistasis);p=np.asarray(g.pred_epistasis);lab=np.abs(y)>threshold
 return dict(n=len(g),epi_spearman=spear(y,p),epi_auroc=float(roc_auc_score(lab,np.abs(p))) if np.unique(lab).size==2 else np.nan,epi_rmse=float(np.sqrt(np.mean((y-p)**2))),z_spearman=spear(g.z_ab,g.pred_z_ab),z_rmse=float(np.sqrt(np.mean((g.z_ab-g.pred_z_ab)**2))),positive_prevalence=float(lab.mean()))
def per_group(d,col,threshold=1.):return pd.DataFrame([{col:k,**score(g,threshold)} for k,g in d.groupby(col,sort=True)])
def validation_score(d,p):
 vals=[spear(g.z_ab-g.z_a-g.z_b,g._pred) for _,g in d.assign(_pred=p).groupby('UniProt_ID')];v=np.asarray(vals);n=int(np.isfinite(v).sum())
 return (float(np.nanmean(v)) if n else np.nan,n)
def validate(d,p):
 if d.duplicated(KEY).any() or p.duplicated(KEY).any() or len(d)!=len(p):raise ValueError('Prediction keys not unique/complete')
 g=d.merge(p[KEY+['pred_epistasis','pred_z_ab']],on=KEY,how='left',validate='one_to_one')
 if not np.isfinite(g[['pred_epistasis','pred_z_ab']].to_numpy()).all():raise ValueError('Missing/nonfinite predictions')
 if not np.allclose(g.pred_z_ab,g.z_a+g.z_b+g.pred_epistasis,atol=1e-6,rtol=1e-6):raise ValueError('Reconstruction mismatch')
 g['epistasis']=g.z_ab-g.z_a-g.z_b;return g

def summaries(d):
 out={'pooled':score(d)}
 for name,col in [('macro_protein','UniProt_ID'),('macro_assay','assay')]:
  t=per_group(d,col);out[name]={k:float(t[k].mean()) for k in METRICS};out[name].update(eligible_spearman=int(t.epi_spearman.notna().sum()),eligible_auroc=int(t.epi_auroc.notna().sum()),n_groups=len(t))
 return out

def json_safe(x):
 if isinstance(x,dict):return {k:json_safe(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [json_safe(v) for v in x]
 if isinstance(x,(float,np.floating)):return float(x) if np.isfinite(x) else None
 if isinstance(x,np.integer):return int(x)
 return x

import os,json,tempfile,hashlib
from pathlib import Path

def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def write(path,fn,binary=False):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix='.'+p.name,suffix='.partial',dir=p.parent)
 try:
  with os.fdopen(fd,'wb' if binary else 'w',**({} if binary else {'encoding':'utf8','newline':''})) as f:fn(f);f.flush();os.fsync(f.fileno())
  os.replace(tmp,p)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
def json_file(x,p):write(p,lambda f:json.dump(x,f,indent=2,default=str,allow_nan=False))
def csv_file(x,p):write(p,lambda f:x.to_csv(f,index=False))
def torch_file(x,p):
 import torch
 write(p,lambda f:torch.save(x,f),True)
def npz_file(x,p):
 import numpy as np
 write(p,lambda f:np.savez_compressed(f,**x),True)

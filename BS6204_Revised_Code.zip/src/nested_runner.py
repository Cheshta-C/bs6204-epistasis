"""One outer-fold job. Every selected search and final seed is exported before advancing."""
import argparse,json,time,os,datetime
from pathlib import Path
import numpy as np,pandas as pd,torch
from atomic_io import sha,json_file,csv_file,torch_file
from model_runtime import Features,make_model,seed_all,group_folds
from scientific_metrics import validate,validation_score,summaries,per_group,json_safe
from persistence import BASE,DURABLE,MANIFEST,check,publish,archive
RUNID='durable_v2'

def optimizer(net,c):return torch.optim.Adam(net.parameters(),lr=c['lr'],weight_decay=c['weight_decay'])
def signature(work,cfgpath,model,protocol,ablation):
 src=Path(__file__).parent
 return {'pairs_sha256':sha(work/'inputs/pairs_struct.csv'),'cache_sha256':sha(work/'caches/wt_emb_650.pt'),'contacts_sha256':sha(work/'inputs/contacts.npz'),'config_sha256':sha(cfgpath),'cluster_sha256':sha(work/'clusters/clusters.csv'),'M1_source_sha256':sha(src/'train_m1.py'),'M2_source_sha256':sha(src/'train_m2.py'),'runtime_source_sha256':sha(src/'model_runtime.py'),'runner_source_sha256':sha(src/'nested_runner.py'),'metrics_source_sha256':sha(src/'scientific_metrics.py'),'model':model,'protocol':protocol,'ablation':ablation,'torch_version':str(torch.__version__),'target':'z_ab-z_a-z_b','hidden':128,'emb_dim':1280}

def verify_seed(job,feats,test_idx,sig,fold,seed):
 cfg=json.load(open(job/'configuration.json'));ck=torch.load(job/'checkpoint.pt',map_location='cpu',weights_only=True)
 assert ck['signature']==sig and ck['outer_fold']==fold and ck['seed']==seed and ck['configuration']==cfg
 train_prot=set(ck['train_proteins']);test=feats.d.iloc[test_idx];assert set(test.UniProt_ID)==set(ck['test_proteins']) and train_prot.isdisjoint(test.UniProt_ID)
 pred=pd.read_csv(job/'heldout_predictions.csv');g=validate(test,pred)
 for col in ['assay','UniProt_ID','mutant','pair_id','true_epistasis','pred_epistasis','z_ab','pred_z_ab','outer_fold','seed']:
  assert col in pred,col
 assert (pred.outer_fold==fold).all() and (pred.seed==seed).all()
 truth=test[['assay','mutant','z_a','z_b','z_ab','UniProt_ID','pair_id']].merge(pred[['assay','mutant','z_a','z_b','z_ab','UniProt_ID','pair_id']],on=['assay','mutant'],validate='one_to_one',suffixes=('_expected','_saved'))
 for c in ['z_a','z_b','z_ab']:assert np.allclose(truth[c+'_expected'],truth[c+'_saved'],atol=1e-10)
 for c in ['UniProt_ID','pair_id']:assert (truth[c+'_expected']==truth[c+'_saved']).all()
 assert np.allclose(pred.true_epistasis,pred.z_ab-pred.z_a-pred.z_b,atol=1e-10)
 net=make_model(sig['model'],cfg);net.load_state_dict(ck['state_dict']);p=feats.predict(net,test_idx,standard=True)
 assert np.allclose(p,g.pred_epistasis,atol=1e-6,rtol=1e-5),'Independent original-class inference mismatch'
 actual=json_safe(summaries(g));saved=json.load(open(job/'metrics.json'))
 assert actual==saved,'Saved metrics differ on replay'
 for f in ['configuration.json','checkpoint.pt','heldout_predictions.csv','metrics.json','per_protein.csv','per_assay.csv','training_history.csv']:
  assert (job/f).is_file()
 record={'signature':sig,'n_test':len(test),'outer_fold':fold,'seed':seed,'inference_verified':True,'max_abs_inference_difference':float(np.max(abs(p-g.pred_epistasis))),'files':{f.name:sha(f) for f in job.iterdir() if f.is_file() and f.name!='verification.json'}}
 json_file(record,job/'verification.json');return record

def tune(feats,train_idx,inner,cfg,fo,fold,sig,protocol,model,work):
 selkey=f'{protocol}/{model}/fold_{fold}';old=json.load(open(MANIFEST)).get('selections',{}).get(selkey)
 selection_path=fo/'selection.json'
 if old and old.get('persisted') and selection_path.exists() and (fo/'search_verification.json').exists():
  v=json.load(open(fo/'search_verification.json'))
  if v['signature']==sig and all((fo/k).exists() and sha(fo/k)==s for k,s in v['files'].items()):
   c=pd.read_csv(fo/'candidates.csv');assert len(c)==len(cfg['candidates'])*cfg['inner_folds'];print('REUSE VERIFIED SEARCH',selkey,flush=True);return json.load(open(selection_path))
 hist=[];cand=[];selected=None;best_score=-np.inf
 for ci,c in enumerate(cfg['candidates']):
  weighted=[];counts=[];epochs=[]
  for inf in range(cfg['inner_folds']):
   check();tr=train_idx[inner!=inf];va=train_idx[inner==inf]
   assert set(feats.d.iloc[tr].UniProt_ID).isdisjoint(feats.d.iloc[va].UniProt_ID)
   if protocol=='cluster':assert set(feats.d.iloc[tr].cluster).isdisjoint(feats.d.iloc[va].cluster)
   seed_all(cfg['selection_seed']+100*fold+inf);net=make_model(model,c);opt=optimizer(net,c);best=-np.inf;epbest=0;wait=0;eligible=0
   for ep in range(1,cfg['max_epochs']+1):
    check();start=time.monotonic();tl=feats.epoch(net,tr,opt);pred=feats.predict(net,va);rho,n=validation_score(feats.d.iloc[va],pred);mse=float(np.mean((pred-feats.y[va].cpu().numpy())**2))
    hist.append({'candidate':ci,'inner_fold':inf,'epoch':ep,'train_mse':tl,'validation_mse':mse,'validation_rmse':mse**.5,'interaction_spearman':rho,'eligible_proteins':n,'seconds':time.monotonic()-start})
    csv_file(pd.DataFrame(hist),fo/'inner_history.csv')
    if np.isfinite(rho) and rho>best+cfg['min_delta']:best=rho;epbest=ep;eligible=n;wait=0
    else:wait+=1
    print(f'{protocol} {model} f{fold} c{ci} i{inf} epoch={ep} rho={rho:.6f} mse={mse:.6f}',flush=True)
    if wait>=cfg['patience']:break
   if not epbest:raise ValueError('No defined inner validation correlation')
   cand.append(dict(candidate=ci,inner_fold=inf,best_epoch=epbest,best_spearman=best,eligible_proteins=eligible,epochs_run=ep,reached_epoch_cap=ep==cfg['max_epochs'],**c));weighted.append(best*eligible);counts.append(eligible);epochs.append(epbest)
   del net,opt
  score=sum(weighted)/sum(counts)
  if selected is None or score>best_score+cfg['min_delta']:
   best_score=score;selected=dict(candidate=ci,score=score,epochs=max(1,int(np.floor(np.median(epochs)+.5))),inner_best_epochs=epochs,**c)
 csv_file(pd.DataFrame(cand),fo/'candidates.csv');json_file(selected,selection_path)
 files=['inner_history.csv','candidates.csv','selection.json','inner_assignments.csv','outer_assignments.csv','preprocessing_metadata.json','normalization_parameters.csv']
 json_file({'signature':sig,'files':{f:sha(fo/f) for f in files}},fo/'search_verification.json')
 z=DURABLE/f'BS6204_Selection_{protocol}_{model}_f{fold}.zip';archive(z,[(fo/f,f'runs/{RUNID}/{protocol}/{model}/fold_{fold}/{f}') for f in files+['search_verification.json']]);publish(z,selection=selkey)
 return selected

def main():
 p=argparse.ArgumentParser();p.add_argument('--work',default=str(BASE/'artifacts'));p.add_argument('--protocol',choices=['protein','cluster'],required=True);p.add_argument('--model',choices=['M1','M2'],required=True);p.add_argument('--fold',type=int,required=True);p.add_argument('--threads',type=int,default=2);p.add_argument('--config',default=str(Path(__file__).resolve().parents[1]/'configs/nested_v1.json'));p.add_argument('--ablation',choices=['full','no_contacts','no_distance'],default='full');a=p.parse_args();check();torch.set_num_threads(a.threads);torch.set_num_interop_threads(1)
 w=Path(a.work);cfg=json.load(open(a.config));audit=json.load(open(w/'audit/input_audit.json'));d=pd.read_csv(w/'inputs/pairs_struct.csv')
 assert audit['cohort_verified'] and audit['matched_sha256']==sha(w/'inputs/pairs_struct.csv') and audit['cache_sha256']==sha(w/'caches/wt_emb_650.pt') and audit['contacts_sha256']==sha(w/'inputs/contacts.npz')
 assert (len(d),d.assay.nunique(),d.UniProt_ID.nunique())==(221340,47,45);assert 'A4_HUMAN' not in set(d.UniProt_ID)
 d=d.merge(pd.read_csv(w/'clusters/clusters.csv'),on='UniProt_ID',how='left',validate='many_to_one');assert d.cluster.notna().all();d['pair_id']=d.assay+'::'+d.mutant
 group='UniProt_ID' if a.protocol=='protein' else 'cluster';outer=group_folds(d,group,cfg['outer_folds']);d['outer_fold']=outer;f=a.fold
 tr=np.flatnonzero(outer!=f);te=np.flatnonzero(outer==f);assert set(d.iloc[tr][group]).isdisjoint(d.iloc[te][group])
 inner=group_folds(d.iloc[tr],group,cfg['inner_folds']);phase_model=a.model if a.ablation=='full' else a.model+'_'+a.ablation
 fo=w/f'runs/{RUNID}/{a.protocol}/{phase_model}/fold_{f}';fo.mkdir(parents=True,exist_ok=True);sig=signature(w,Path(a.config),a.model,a.protocol,a.ablation)
 if (fo/'signature.json').exists():assert json.load(open(fo/'signature.json'))==sig,'Changed experiment signature'
 json_file(sig,fo/'signature.json');csv_file(d[['assay','UniProt_ID','cluster','outer_fold']].drop_duplicates(),fo/'outer_assignments.csv')
 ii=d.iloc[tr][['assay','UniProt_ID','cluster']].copy();ii['inner_fold']=inner;csv_file(ii.drop_duplicates(),fo/'inner_assignments.csv');json_file(audit,fo/'preprocessing_metadata.json');csv_file(pd.read_csv(w/'inputs/assay_fits.csv'),fo/'normalization_parameters.csv')
 emb=torch.load(w/'caches/wt_emb_650.pt',weights_only=True,map_location='cpu');feats=Features(d,emb,dict(np.load(w/'inputs/contacts.npz')),a.model,ablation=a.ablation)
 sel=tune(feats,tr,inner,cfg,fo,f,sig,a.protocol,phase_model,w)
 for seed in cfg['final_seeds']:
  check();key=f'{a.protocol}/{phase_model}/fold_{f}/seed_{seed}';job=fo/f'seed_{seed}';job.mkdir(exist_ok=True);status=json.load(open(MANIFEST))['jobs'].get(key,{})
  if status.get('persisted') and status.get('verified'):
   try:
    assert all((job/n).is_file() and sha(job/n)==v for n,v in status['files'].items()),'Saved artifact hash mismatch'
    verify_seed(job,feats,te,sig,f,seed);print('REUSE VERIFIED SEED',key,flush=True);continue
   except (OSError,ValueError,AssertionError,KeyError):print('Invalid saved job; rerunning',key,flush=True)
  seed_all(seed);net=make_model(a.model,sel);opt=optimizer(net,sel);hist=[]
  for ep in range(1,sel['epochs']+1):
   check();tl=feats.epoch(net,tr,opt);hist.append({'epoch':ep,'train_mse':tl,'seed':seed});csv_file(pd.DataFrame(hist),job/'training_history.csv');print(f'FINAL {key} epoch={ep}/{sel["epochs"]} mse={tl:.6f}',flush=True)
  # Save the trained state before any held-out evaluation or file assembly.
  ck={'state_dict':net.state_dict(),'signature':sig,'configuration':sel,'seed':seed,'outer_fold':f,'train_proteins':sorted(d.iloc[tr].UniProt_ID.unique()),'test_proteins':sorted(d.iloc[te].UniProt_ID.unique()),'calibration_parameters':None,'calibration_note':'No fitted double-mutant reference','target':'naive_epistasis','threads':a.threads}
  torch_file(ck,job/'checkpoint.pt');json_file(sel,job/'configuration.json')
  pred=feats.predict(net,te);pp=d.iloc[te].copy();pp['true_epistasis']=pp.z_ab-pp.z_a-pp.z_b;pp['pred_epistasis']=pred;pp['pred_z_ab']=pp.z_a+pp.z_b+pred;pp['seed']=seed;pp['model']=phase_model;pp['protocol']=a.protocol
  csv_file(pp,job/'heldout_predictions.csv');saved=pd.read_csv(job/'heldout_predictions.csv');g=validate(d.iloc[te],saved)
  assert np.allclose(pred,g.pred_epistasis,atol=1e-6,rtol=1e-6)
  json_file(json_safe(summaries(g)),job/'metrics.json');csv_file(per_group(g,'UniProt_ID'),job/'per_protein.csv');csv_file(per_group(g,'assay'),job/'per_assay.csv')
  record=verify_seed(job,feats,te,sig,f,seed)
  files=[(x,f'runs/{RUNID}/{a.protocol}/{phase_model}/fold_{f}/seed_{seed}/{x.name}') for x in job.iterdir() if x.is_file()]
  files += [(fo/n,f'runs/{RUNID}/{a.protocol}/{phase_model}/fold_{f}/{n}') for n in ['selection.json','candidates.csv','inner_history.csv','outer_assignments.csv','inner_assignments.csv','preprocessing_metadata.json','normalization_parameters.csv','signature.json','search_verification.json']]
  z=DURABLE/f'BS6204_{phase_model}_{a.protocol}_f{f}_s{seed}.zip';archive(z,files);publish(z,job=key,job_record=record);del net,opt
 json_file({'all_seeds_verified_and_persisted':True,'signature':sig},fo/'COMPLETE.json')
 print('OUTER COMPLETE',a.protocol,phase_model,f,flush=True)
if __name__=='__main__':main()

import json,hashlib,subprocess,sys,tarfile
from pathlib import Path
import numpy as np,pandas as pd,torch
from atomic_io import sha,json_file,csv_file
from model_runtime import group_folds
from persistence import BASE,DURABLE,archive,publish

def main():
 w=BASE/'artifacts';out=w/'audit';out.mkdir(exist_ok=True);h=pd.read_csv(w/'original/pairs.csv');d=pd.read_csv(w/'inputs/pairs.csv');p=pd.read_csv(w/'inputs/pairs_struct.csv');seq=pd.read_csv(w/'inputs/sequences.csv');fits=pd.read_csv(w/'inputs/assay_fits.csv')
 assert h[['assay','mutant']].equals(d[['assay','mutant']]);assert (len(d),d.assay.nunique(),d.UniProt_ID.nunique())==(235355,48,46);assert (len(p),p.assay.nunique(),p.UniProt_ID.nunique())==(221340,47,45);assert 'A4_HUMAN' not in set(p.UniProt_ID)
 assert p[['assay','mutant']].reset_index(drop=True).equals(h[h.UniProt_ID!='A4_HUMAN'][['assay','mutant']].reset_index(drop=True));assert not p.duplicated(['assay','mutant']).any();assert 'z_additive_fit' not in p
 assert sha(w/'inputs/pairs_struct.csv')=='4277f5a8631d0b4be22e431ff3bd02c3c4870c30a488b3af19f65a07ad9cb459','Reconstructed matched inputs differ from recorded hash'
 norm=[]
 for r in fits.itertuples():
  raw=pd.read_csv(w/'data/DMS_ProteinGym_substitutions'/f'{r.assay}.csv').dropna(subset=['DMS_score']);n=raw.mutant.str.count(':')+1;s=raw.loc[n==1,'DMS_score'];assert np.isclose(s.mean(),r.score_mean) and np.isclose(s.std(ddof=1),r.score_sd)
  raw.loc[n==2,'DMS_score']=1e12;assert np.isclose(raw.loc[n==1,'DMS_score'].mean(),r.score_mean) and np.isclose(raw.loc[n==1,'DMS_score'].std(ddof=1),r.score_sd)
  norm.append({'assay':r.assay,'n_singles':len(s),'mean':r.score_mean,'sd_ddof1':r.score_sd,'double_intervention_pass':True})
 csv_file(pd.DataFrame(norm),out/'normalization_intervention.csv')
 changes=d[['assay','mutant','z_a','z_b','z_ab','epistasis']].copy()
 for col in ['z_a','z_b','z_ab','epistasis']:changes['historical_'+col]=h[col].to_numpy();changes['delta_'+col]=d[col]-h[col]
 changes['historical_naive_epistasis']=h.epistasis_naive;csv_file(changes,out/'target_changes.csv')
 old=pd.read_csv(BASE/'bs6204-epistasis/results/eval_per_assay.csv');rmse=h.assign(sq=(h.z_ab-h.z_a-h.z_b)**2).groupby('assay').sq.mean().pow(.5);cmp=old[['assay','z_rmse']].copy();cmp['recovered_z_rmse']=cmp.assay.map(rmse);cmp['absolute_difference']=abs(cmp.z_rmse-cmp.recovered_z_rmse);assert cmp.absolute_difference.max()<1e-12;csv_file(cmp,out/'historical_baseline_reproduction.csv')
 mapping=pd.read_csv(w/'inputs/structure_mapping_residues.csv');assert mapping.residue_matches.all();assert len(mapping)==7126
 emb=torch.load(w/'caches/wt_emb_650.pt',weights_only=True,map_location='cpu');prov=json.load(open(w/'caches/wt_emb_650.json'));contacts=dict(np.load(w/'inputs/contacts.npz'))
 for r in seq[seq.assay.isin(p.assay)].itertuples():
  assert emb[r.assay].shape==(len(r.target_seq),1280) and torch.isfinite(emb[r.assay]).all();assert prov['sequences'][r.assay]==hashlib.sha256(r.target_seq.encode()).hexdigest();assert r.assay in contacts
  if contacts[r.assay].size:assert contacts[r.assay].min()>=1 and contacts[r.assay].max()<=len(r.target_seq)
 m={'cohort_verified':True,'full_counts':[235355,48,46],'matched_counts':[221340,47,45],'matched_sha256':sha(w/'inputs/pairs_struct.csv'),'cache_sha256':sha(w/'caches/wt_emb_650.pt'),'contacts_sha256':sha(w/'inputs/contacts.npz'),'single_only_normalization':True,'sd_ddof':1,'normalization_intervention_passed':True,'no_fitted_double_reference':True,'target':'z_ab-z_a-z_b','conditional_singles_available':True,'pair_keys_preserved':True,'mapped_residues':len(mapping),'mapping_mismatches':0,'strong_prevalence':float((p.epistasis.abs()>1).mean()),'eligible_auroc_assays':int(p.groupby('assay').epistasis.apply(lambda s:(s.abs()>1).nunique()==2).sum()),'historical_max_rmse_difference':float(cmp.absolute_difference.max())}
 json_file(m,out/'input_audit.json');print(json.dumps(m,indent=2),flush=True)
 # Independently re-run the recorded MMseqs rule; reuse recovered components only after equality.
 tools=w/'tools';tools.mkdir(exist_ok=True)
 with tarfile.open(w/'downloads/mmseqs.tar.gz') as t:t.extractall(tools,filter='data')
 binary=tools/'mmseqs/bin/mmseqs';cl=w/'clusters';cl.mkdir(exist_ok=True);s=seq[seq.assay.isin(p.assay)];fasta=cl/'assays.fasta';fasta.write_text(''.join(f'>{r.assay}\n{r.target_seq}\n' for r in s.itertuples()))
 cmd=[str(binary),'easy-search',str(fasta),str(fasta),str(cl/'alignments.tsv'),str(cl/'tmp'),'--min-seq-id','0.3','-c','0','-e','0.001','-s','7.5','--max-seqs','1000','--threads','4','--alignment-mode','3','--format-output','query,target,fident,alnlen,qcov,tcov,evalue,bits']
 with open(cl/'mmseqs.log','w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 hits=pd.read_csv(cl/'alignments.tsv',sep='\t',names=['query','target','identity','aligned_length','qcov','tcov','evalue','bits']);a2p=dict(zip(s.assay,s.UniProt_ID));proteins=sorted(s.UniProt_ID.unique());parent={x:x for x in proteins}
 def find(x):
  while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
  return x
 accepted=[]
 for r in hits.itertuples():
  if r.query==r.target:continue
  whole=min(r.qcov,r.tcov)>=.8;domain=max(r.qcov,r.tcov)>=.8 and r.aligned_length>=40 and r.evalue<=.001
  if r.identity>=.3 and (whole or domain):
   x,y=find(a2p[r.query]),find(a2p[r.target]);parent[max(x,y)]=min(x,y);accepted.append(dict(r._asdict(),rule='whole' if whole else 'domain'))
 clusters=pd.DataFrame({'UniProt_ID':proteins,'cluster':[find(x) for x in proteins]});oldcl=pd.read_csv(BASE/'recovered_record/Recovered_Cluster_Assignments.csv');pd.testing.assert_frame_equal(clusters.sort_values('UniProt_ID').reset_index(drop=True),oldcl.sort_values('UniProt_ID').reset_index(drop=True));assert clusters.cluster.nunique()==39
 csv_file(clusters,cl/'clusters.csv');csv_file(pd.DataFrame(accepted),cl/'accepted_homology_edges.csv');json_file({'mmseqs_version':subprocess.check_output([str(binary),'version'],text=True).strip(),'binary_archive_sha256':sha(w/'downloads/mmseqs.tar.gz'),'command':cmd,'n_clusters':39,'n_proteins':45,'recovered_assignments_independently_verified':True,'remote_homology_caveat':'This alignment heuristic cannot prove absence of arbitrary remote homology.'},cl/'clustering_manifest.json')
 for protocol,col in [('protein','UniProt_ID'),('cluster','cluster')]:
  dd=p.merge(clusters,on='UniProt_ID',how='left',validate='many_to_one');dd['outer_fold']=group_folds(dd,col,5);od=dd[['assay','UniProt_ID','cluster','outer_fold']].drop_duplicates();csv_file(od,cl/f'{protocol}_outer_assignments.csv');rec=pd.read_csv(BASE/f'recovered_record/Reconstructed_{protocol}_Outer_Assignments.csv');pd.testing.assert_frame_equal(od.sort_values('assay').reset_index(drop=True),rec[od.columns].sort_values('assay').reset_index(drop=True))
 m['homology_components']=39;m['clusters_sha256']=sha(cl/'clusters.csv');json_file(m,out/'input_audit.json')
 # Publish independently reusable resource bundles, avoiding duplicated partial caches.
 files=[(f,'artifacts/inputs/'+f.name) for f in (w/'inputs').iterdir() if f.is_file()]
 files += [(f,'artifacts/clusters/'+f.name) for f in (w/'clusters').iterdir() if f.is_file()]
 files += [(out/'input_audit.json','artifacts/audit/input_audit.json')]
 z=DURABLE/'BS6204_Canonical_Input_Tables.zip';archive(z,files);publish(z)
 files=[(f,'artifacts/audit/'+f.name) for f in out.iterdir() if f.is_file()]
 files += [(f,'artifacts/original/'+f.name) for f in (w/'original').iterdir() if f.is_file()]
 z=DURABLE/'BS6204_Preprocessing_Audit.zip';archive(z,files);publish(z)
if __name__=='__main__':main()

"""Tables from saved, key-complete OOF predictions. Whole-group paired inference."""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
from scientific_metrics import score,per_group,validate,METRICS,json_safe
from atomic_io import csv_file,json_file

def collect(work,protocol,model):
 r=Path(work)/f'runs/durable_v2/{protocol}/{model}';d=pd.read_csv(Path(work)/'inputs/pairs_struct.csv');allpred=[]
 for seed in [0,1,2]:
  chunks=[]
  for fold in range(5):
   f=r/f'fold_{fold}';assert (f/'COMPLETE.json').exists(),f'Incomplete {f}';chunks.append(pd.read_csv(f/f'seed_{seed}/heldout_predictions.csv'))
  p=pd.concat(chunks,ignore_index=True);validate(d,p);csv_file(p,r/f'OOF_seed_{seed}.csv');allpred.append((seed,p))
 return allpred

def paired_ci(tables,pairs,clusters,protocol,nboot=2000):
 rng=np.random.default_rng(2026);rows=[];pmap=pairs.groupby('assay').UniProt_ID.first().to_dict();umap=dict(zip(clusters.UniProt_ID,clusters.cluster)) if protocol=='cluster' else {x:x for x in pairs.UniProt_ID.unique()};units=sorted(set(umap.values()));uid={x:i for i,x in enumerate(units)}
 for level,col in [('protein','UniProt_ID'),('assay','assay')]:
  tab=tables[level]
  for metric in METRICS:
   v=tab[tab.model.isin(['M1','M2'])].groupby(['model',col])[metric].mean().unstack('model')
   if not {'M1','M2'}.issubset(v.columns):continue
   v=v.dropna(subset=['M1','M2'])
   if not len(v):continue
   ix=np.array([uid[umap[k if level=='protein' else pmap[k]]] for k in v.index]);a=v.M1.to_numpy();b=v.M2.to_numpy();samples=[]
   for _ in range(nboot):
    w=np.bincount(rng.integers(0,len(units),len(units)),minlength=len(units))[ix]
    if w.sum():samples.append([np.average(a,weights=w),np.average(b,weights=w),np.average(b-a,weights=w)])
   arr=np.asarray(samples);lo,hi=np.percentile(arr,[2.5,97.5],axis=0)
   rows.append({'aggregation':'macro_'+level,'metric':metric,'M1':a.mean(),'M2':b.mean(),'M2_minus_M1':(b-a).mean(),'ci_low':lo[2],'ci_high':hi[2],'M1_ci_low':lo[0],'M1_ci_high':hi[0],'M2_ci_low':lo[1],'M2_ci_high':hi[1],'bootstrap_unit':'whole_similarity_component' if protocol=='cluster' else 'whole_protein','bootstrap_replicates':nboot,'finite_resamples':len(arr),'eligible_groups':len(v)})
 return pd.DataFrame(rows)

def evaluate(work,protocol,models,out):
 work=Path(work);out=Path(out);out.mkdir(parents=True,exist_ok=True);pairs=pd.read_csv(work/'inputs/pairs_struct.csv');tables={'protein':[],'assay':[]};summary=[];geometry=[];sensitivity=[]
 for model in ['M0']+models:
  if model=='M0':
   p=pairs[['assay','mutant']].copy();p['pred_epistasis']=0.;p['pred_z_ab']=pairs.z_a+pairs.z_b;preds=[(0,p)]
  else:preds=collect(work,protocol,model)
  for seed,p in preds:
   d=validate(pairs,p);lab=abs(d.epistasis)>1
   for level,col in [('protein','UniProt_ID'),('assay','assay')]:
    t=per_group(d,col);t['model']=model;t['seed']=seed;tables[level].append(t);s={k:float(t[k].mean()) for k in METRICS};summary.append(dict(model=model,seed=seed,aggregation='macro_'+level,**s,n_pairs=len(d),n_groups=len(t),eligible_spearman=int(t.epi_spearman.notna().sum()),eligible_auroc=int(t.epi_auroc.notna().sum()),positive_prevalence=float(lab.mean())))
   summary.append(dict(model=model,seed=seed,aggregation='pooled',**score(d),n_pairs=len(d),n_groups=1))
   far=d.seq_distance>=5;contact=d.dist_3d<=8
   masks={'ALL':np.ones(len(d),bool),'sequence_near_contact':~far&contact,'sequence_near_noncontact':~far&~contact,'sequence_far_contact':far&contact,'sequence_far_noncontact':far&~contact}
   for label,mask in masks.items():
    g=d[mask]
    if len(g):geometry.append(dict(model=model,seed=seed,slice=label,**score(g),n_proteins=g.UniProt_ID.nunique(),n_assays=g.assay.nunique()))
   for threshold in [.5,1.,1.5]:
    for level,col in [('protein','UniProt_ID'),('assay','assay')]:
     t=per_group(d,col,threshold);sensitivity.append(dict(model=model,seed=seed,aggregation='macro_'+level,threshold=threshold,epi_auroc=float(t.epi_auroc.mean()),eligible_groups=int(t.epi_auroc.notna().sum()),positive_prevalence=float((abs(d.epistasis)>threshold).mean())))
 s=pd.DataFrame(summary);csv_file(s,out/'metrics_by_seed.csv');mean=s.groupby(['model','aggregation'])[METRICS].agg(['mean','std']);mean.columns=['_'.join(x) for x in mean.columns];csv_file(mean.reset_index(),out/'metrics_summary.csv')
 for level in tables:tables[level]=pd.concat(tables[level],ignore_index=True);csv_file(tables[level],out/f'per_{level}.csv')
 csv_file(pd.DataFrame(geometry),out/'geometry_metrics.csv');csv_file(pd.DataFrame(sensitivity),out/'threshold_sensitivity.csv')
 if {'M1','M2'}.issubset(models):csv_file(paired_ci(tables,pairs,pd.read_csv(work/'clusters/clusters.csv'),protocol),out/'paired_confidence_intervals.csv')
 meta={'protocol':protocol,'models':models,'n_pairs':len(pairs),'n_assays':pairs.assay.nunique(),'n_proteins':pairs.UniProt_ID.nunique(),'primary':'macro-protein interaction Spearman and AUROC','mean_is':'mean of per-seed metrics, not an ensemble','threshold':1.,'strong_prevalence':float((abs(pairs.epistasis)>1).mean()),'eligible_auroc_assays':int(pairs.groupby('assay').epistasis.apply(lambda x:(abs(x)>1).nunique()==2).sum()),'M0_spearman':'undefined','CI_scope':'Conditional on saved OOF fits; training datasets are not refitted per bootstrap sample','normalization':'measured singles only, sample SD ddof=1','target':'z_ab-z_a-z_b'};json_file(meta,out/'evaluation_manifest.json');print(mean.to_string(),flush=True)
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('work');p.add_argument('--protocol',required=True);p.add_argument('--models',nargs='+',default=['M1','M2']);p.add_argument('--out',required=True);a=p.parse_args();evaluate(a.work,a.protocol,a.models,a.out)
if __name__=='__main__':main()

"""Independent replay of every actual saved model, split and published metric table."""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd,torch
from atomic_io import sha,json_file,csv_file
from model_runtime import Features,group_folds
from nested_runner import verify_seed,signature
from evaluate_results import evaluate
from persistence import MANIFEST,check

def main():
 p=argparse.ArgumentParser();p.add_argument('work');a=p.parse_args();w=Path(a.work);torch.set_num_threads(2);out=w/'verification';out.mkdir(exist_ok=True);base=pd.read_csv(w/'inputs/pairs_struct.csv');cl=pd.read_csv(w/'clusters/clusters.csv');d=base.merge(cl,on='UniProt_ID',how='left',validate='many_to_one');d['pair_id']=d.assay+'::'+d.mutant;m=json.load(open(MANIFEST));rows=[]
 cfg=Path(__file__).resolve().parents[1]/'configs/nested_v1.json'
 for protocol in ['protein','cluster']:
  group='UniProt_ID' if protocol=='protein' else 'cluster';outer=group_folds(d,group,5);d['outer_fold']=outer;outer_reference=None;inner_reference={}
  for model in ['M1','M2']:
   sig=signature(w,cfg,model,protocol,'full');feats=Features(d,torch.load(w/'caches/wt_emb_650.pt',weights_only=True,map_location='cpu'),dict(np.load(w/'inputs/contacts.npz')),model)
   for f in range(5):
    fo=w/f'runs/durable_v2/{protocol}/{model}/fold_{f}';assert (fo/'COMPLETE.json').exists();tr=d[outer!=f];te=d[outer==f]
    assert set(tr.UniProt_ID).isdisjoint(te.UniProt_ID);assert set(tr[group]).isdisjoint(te[group])
    assignment=pd.read_csv(fo/'outer_assignments.csv').sort_values('assay').reset_index(drop=True)
    if outer_reference is None:outer_reference=assignment
    else:pd.testing.assert_frame_equal(outer_reference,assignment)
    inner=pd.read_csv(fo/'inner_assignments.csv').sort_values('assay').reset_index(drop=True)
    if f not in inner_reference:inner_reference[f]=inner
    else:pd.testing.assert_frame_equal(inner_reference[f],inner)
    assert set(inner.UniProt_ID)==set(tr.UniProt_ID);assert not set(inner.UniProt_ID)&set(te.UniProt_ID);assert (inner.groupby('UniProt_ID').inner_fold.nunique()==1).all()
    if protocol=='cluster':assert (inner.groupby('cluster').inner_fold.nunique()==1).all()
    for seed in [0,1,2]:
     key=f'{protocol}/{model}/fold_{f}/seed_{seed}';rec=m['jobs'][key];assert rec['persisted'] and rec['verified'] and rec['artifact']['library_file_id'];job=fo/f'seed_{seed}'
     assert all(sha(job/n)==v for n,v in rec['files'].items());r=verify_seed(job,feats,np.flatnonzero(outer==f),sig,f,seed);rows.append(dict(protocol=protocol,model=model,fold=f,seed=seed,n_test=r['n_test'],max_abs_inference_difference=r['max_abs_inference_difference'],checkpoint_sha256=sha(job/'checkpoint.pt'),persisted_library_file_id=rec['artifact']['library_file_id'],passed=True))
   del feats
  replay=out/protocol;evaluate(w,protocol,['M1','M2'],replay)
  for f in replay.glob('*.csv'):assert sha(f)==sha(w/f'evaluation/{protocol}'/f.name),f'Evaluation table differs on replay: {f}'
 assert len(rows)==60;csv_file(pd.DataFrame(rows),out/'checkpoint_replay.csv');json_file({'checkpoints_verified':60,'unique_complete_oof_keys':True,'reconstruction_identity':True,'protein_overlap':0,'cluster_overlap_in_robustness':0,'M1_M2_identical_splits':True,'evaluation_csv_byte_identical':True,'all_seed_packages_persisted':True},out/'verification.json');print('PASS all 60 actual checkpoints and all published tables',flush=True)
if __name__=='__main__':main()

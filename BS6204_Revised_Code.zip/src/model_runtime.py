"""Execute the original classes with equivalent factored M1 and disconnected sparse M2."""
import random
import numpy as np,torch
from train_m1 import EpistasisHead,AA_IDX
from train_m2 import M2,norm_adj

def seed_all(seed):
 random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.use_deterministic_algorithms(True)
def make_model(name,cfg,device='cpu'):
 return (EpistasisHead(1280,hidden=128,dropout=cfg['dropout']) if name=='M1' else M2(1280,hidden=128,dropout=cfg['dropout'])).to(device)
def group_folds(d,col,k):
 counts=d.groupby(col).size().sort_values(ascending=False,kind='stable');bins=[0]*k;mp={}
 if len(counts)<k:raise ValueError('Insufficient independent groups')
 for g,n in counts.items():f=int(np.argmin(bins));mp[g]=f;bins[f]+=int(n)
 return d[col].map(mp).to_numpy()
class Features:
 def __init__(self,d,emb,contacts,name,device='cpu',ablation='full'):
  self.d=d;self.name=name;self.device=device;self.assays=d.assay.to_numpy();self.X={};self.adj={};offset={};n=0
  for a in sorted(d.assay.unique()):
   x=emb[a].float().to(device)
   if x.shape[1]!=1280 or not torch.isfinite(x).all():raise ValueError('Invalid ESM-2 650M features')
   self.X[a]=x;offset[a]=n;n+=len(x)
   if name=='M2':self.adj[a]=norm_adj(len(x),contacts[a] if ablation!='no_contacts' else []).to(device)
  self.allX=torch.cat(list(self.X.values()))
  if name=='M2':
   ix=[];val=[]
   for a,adj in self.adj.items():
    sp=adj.to_sparse().coalesce();ix.append(sp.indices()+offset[a]);val.append(sp.values())
   self.blockadj=torch.sparse_coo_tensor(torch.cat(ix,1),torch.cat(val),(n,n),device=device,check_invariants=True).coalesce()
  def t(x,dtype=torch.float32):return torch.tensor(np.asarray(x),dtype=dtype,device=device)
  off=d.assay.map(offset).to_numpy();self.ia=t(d.pos_a-1+off,torch.long);self.ib=t(d.pos_b-1+off,torch.long);self.ra=t(d.pos_a-1,torch.long);self.rb=t(d.pos_b-1,torch.long)
  for attr,col in [('wta','wt_a'),('muta','aa_a'),('wtb','wt_b'),('mutb','aa_b')]:setattr(self,attr,t([AA_IDX.get(x,20) for x in d[col]],torch.long))
  self.za=t(d.z_a);self.zb=t(d.z_b);self.sd=t((d.seq_distance/100).clip(0,5));self.d3=t(d.dist_3d/10);self.y=t(d.z_ab-d.z_a-d.z_b)
  if ablation=='no_distance':self.d3.zero_()
 def forward(self,net,b,h=None):
  if self.name=='M1':
   ids,inv=torch.unique(torch.cat([self.ia[b],self.ib[b]]),return_inverse=True);lin=net.site.net[0];ctx=torch.nn.functional.linear(self.allX[ids],lin.weight[:,:1280],lin.bias)
   def site(index,wt,mut):
    aa=torch.cat([net.site.aa(wt),net.site.aa(mut)],-1);s=ctx[index]+torch.nn.functional.linear(aa,lin.weight[:,1280:])
    for layer in list(net.site.net.children())[1:]:s=layer(s)
    return s
   n=len(b);s=site(inv[:n],self.wta[b],self.muta[b])+site(inv[n:],self.wtb[b],self.mutb[b]);sc=torch.stack([self.za[b]+self.zb[b],abs(self.za[b]-self.zb[b]),self.sd[b]],-1)
   return net.head(torch.cat([s,sc],-1)).squeeze(-1)
  h=net.gnn(self.blockadj,self.allX) if h is None else h
  sc=torch.stack([self.za[b]+self.zb[b],abs(self.za[b]-self.zb[b]),self.d3[b],self.sd[b]],-1)
  return net.pair(h[self.ia[b]],self.wta[b],self.muta[b],h[self.ib[b]],self.wtb[b],self.mutb[b],sc)
 def epoch(self,net,idx,opt):
  net.train();order=np.random.permutation(idx);bs=4096 if self.name=='M1' else 2048;total=0.
  for i in range(0,len(order),bs):
   b=order[i:i+bs];p=self.forward(net,b);loss=torch.nn.functional.mse_loss(p,self.y[b]);opt.zero_grad(set_to_none=True);loss.backward();opt.step();total+=float(loss.detach())*len(b)
  return total/len(idx)
 def predict(self,net,idx,standard=False):
  net.eval();pred=[]
  with torch.inference_mode():
   h=net.gnn(self.blockadj,self.allX) if self.name=='M2' and not standard else None
   oldh={a:net.gnn(self.adj[a],self.X[a]) for a in self.X} if self.name=='M2' and standard else {}
   for b in np.array_split(idx,max(1,int(np.ceil(len(idx)/2048)))):
    if not standard:p=self.forward(net,b,h)
    elif self.name=='M1':p=net(self.allX[self.ia[b]],self.wta[b],self.muta[b],self.allX[self.ib[b]],self.wtb[b],self.mutb[b],self.za[b],self.zb[b],self.sd[b])
    else:
     p=torch.empty(len(b),device=self.device);ba=self.assays[b]
     for a in np.unique(ba):
      loc=np.flatnonzero(ba==a);gi=b[loc];hh=oldh[a];sc=torch.stack([self.za[gi]+self.zb[gi],abs(self.za[gi]-self.zb[gi]),self.d3[gi],self.sd[gi]],-1)
      p[torch.as_tensor(loc,device=self.device)]=net.pair(hh[self.ra[gi]],self.wta[gi],self.muta[gi],hh[self.rb[gi]],self.wtb[gi],self.mutb[gi],sc)
    pred.append(p.cpu().numpy())
  return np.concatenate(pred)

"""Export final deliverables only after scientific replay and visual PDF review."""
import sys,json,subprocess,fcntl,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,MANIFEST,REGISTRY,archive,publish,_send
from atomic_io import json_file,sha
def main():
 w=BASE/'artifacts';v=json.load(open(w/'verification/verification.json'));assert v['checkpoints_verified']==60 and v['all_seed_packages_persisted'] and v['evaluation_csv_byte_identical']
 pdf=DURABLE/'BS6204_Final_Scientific_Report.pdf';qa=json.load(open(w/'final/pdf_visual_qa.json'));assert qa['passed'] and qa['report_sha256']==sha(pdf) and qa['all_pages_inspected']
 record_audit=json.load(open(w/'verification/selection_and_training_record_audit.json'));assert record_audit['jobs_verified']==sum(bool(x.get('verified') and x.get('persisted')) for x in json.load(open(MANIFEST))['jobs'].values())
 archive_audit=json.load(open(w/'verification/exported_archive_integrity_audit.json'));assert archive_audit['individual_job_archives_verified']==90 and archive_audit['aggregate_model_and_baseline_archives_verified']==5 and archive_audit['all_required_payload_hashes_match_replayed_files']
 m=json.load(open(MANIFEST));m['status']='scientific_experiments_verified_saving_final_deliverables';m['final_verification']=v;m['saved_record_audit']=record_audit;m['exported_archive_integrity_audit']=archive_audit
 if (w/'ablations/verification.json').exists():m['structural_ablation_verification']=json.load(open(w/'ablations/verification.json'))
 for old in m.get('uncertain_exports',[]):old['required_for_reproduction']=False;old['superseded_by_verified_artifacts']=['BS6204_Canonical_Input_Tables.zip','BS6204_Embedding_Cache.zip','BS6204_Preprocessing_Audit.zip']
 json_file(m,MANIFEST)
 publish(pdf)
 # Capture final reproducibility state; no trained architecture source is edited here.
 subprocess.run(['git','-C',str(ROOT),'bundle','create',str(DURABLE/'bs6204-corrected.bundle'),'--all'],check=True)
 patch=subprocess.check_output(['git','-C',str(ROOT),'diff','404f8bbba83f3ecfa92f1de0d43d89385db1d0ee','HEAD']);(DURABLE/'bs6204-corrections.patch').write_bytes(patch)
 names=subprocess.check_output(['git','-C',str(ROOT),'ls-files','-z']).decode().split('\0');files=[(ROOT/n,n) for n in names if n and (ROOT/n).is_file()];files += [(DURABLE/'bs6204-corrected.bundle','BS6204_Code_Branch.bundle'),(DURABLE/'bs6204-corrections.patch','BS6204_Corrections.patch')]
 files += [(BASE/'.persistent_export_v2'/n,'hosted_transfer_helpers/'+n) for n in ['library_upload.py','library_download.py','library_file_transfer.py','library_hosted_apps.py','run_upload_with_timeout.py']]
 archive(DURABLE/'BS6204_Revised_Code.zip',files);publish(DURABLE/'BS6204_Revised_Code.zip')
 # Complete configuration package includes actual decisions and split records.
 configfiles=[(p,'recovered_record/'+str(p.relative_to(BASE/'recovered_record'))) for p in (BASE/'recovered_record').rglob('*') if p.is_file()]
 for folder in [ROOT/'configs',w/'environment',w/'clusters']:
  configfiles += [(p,('configs/' if folder==ROOT/'configs' else 'verified/'+folder.name+'/')+str(p.relative_to(folder))) for p in folder.rglob('*') if p.is_file() and 'tmp' not in p.parts]
 for n in ['input_audit.json','normalization_intervention.csv','historical_baseline_reproduction.csv']:configfiles.append((w/'audit'/n,'verified/audit/'+n))
 for n in ['assay_fits.csv','structure_mapping.csv','structure_mapping_residues.csv']:configfiles.append((w/'inputs'/n,'verified/'+n))
 configfiles.append((w/'downloads/public_resource_manifest.json','verified/resource_manifest.json'))
 selected=['selection.json','candidates.csv','inner_history.csv','inner_assignments.csv','outer_assignments.csv','normalization_parameters.csv','preprocessing_metadata.json','signature.json','search_verification.json']
 for folder in (w/'runs/durable_v2').glob('*/*/fold_*'):
  configfiles += [(folder/n,'actual_runs/'+str(folder.relative_to(w/'runs/durable_v2'))+'/'+n) for n in selected if (folder/n).is_file()]
 archive(DURABLE/'BS6204_Recovered_Configuration.zip',configfiles);publish(DURABLE/'BS6204_Recovered_Configuration.zip')
 presentation=[(p,str(p.relative_to(w/'final'))) for p in (w/'final').rglob('*') if p.is_file() and (p.suffix in ['.svg','.png','.csv'] or p.name in ['BS6204_Presentation_Content.md','model_specifications.json'])]
 presentation += [(p,'structural_diagnostics/'+str(p.relative_to(w/'ablations'))) for p in (w/'ablations').rglob('*') if p.is_file()]
 presentation.append((ROOT/'make_final_outputs.py','make_final_outputs.py'));archive(DURABLE/'BS6204_Presentation_Content.zip',presentation);publish(DURABLE/'BS6204_Presentation_Content.zip')
 receipts=json.load(open(REGISTRY));index={n:r for n,r in receipts.items() if n!='BS6204_Final_Results.zip' and not n.startswith('BS6204_Selection_') and not ('_f' in n and '_s' in n)}
 if 'BS6204_Progress_Manifest.json' in index:index['BS6204_Progress_Manifest.json']={k:v for k,v in index['BS6204_Progress_Manifest.json'].items() if k in ['library_file_id','url']};index['BS6204_Progress_Manifest.json']['mutable_latest_manifest']=True
 json_file(index,w/'final/artifact_download_index.json')
 lines=['# Verified BS6204 files','', 'All final model packages contain actual checkpoints and held-out predictions. The source/configuration and cache packages reconstruct the original matched cohort.','']
 for n,r in index.items():lines.append(f"- [{n}]({r['url']})"+(" | Mutable progress record; use the latest version" if r.get('mutable_latest_manifest') else f" | SHA-256 `{r['sha256']}` | {r['bytes']:,} bytes"))
 lines += ['','The final-results package contains tables, chart sources, verification evidence and presentation content. Complete model checkpoints remain in the named protein/cluster packages. Unconfirmed historical exports are not required.',''];(w/'final/BS6204_Download_Index.md').write_text('\n'.join(lines))
 files=[]
 for folder in [w/'final',w/'evaluation',w/'verification',w/'ablations',w/'environment']:
  files += [(f,'artifacts/'+str(f.relative_to(w))) for f in folder.rglob('*') if f.is_file() and 'rendered' not in f.parts]
 files += [(pdf,pdf.name),(MANIFEST,MANIFEST.name)]
 files += [(f,'artifacts/baseline/'+str(f.relative_to(w/'baseline'))) for f in (w/'baseline').rglob('*') if f.is_file() and f.name!='heldout_predictions.csv']
 for n in ['input_audit.json','normalization_intervention.csv','historical_baseline_reproduction.csv']:files.append((w/'audit'/n,'artifacts/audit/'+n))
 for n in ['clustering_manifest.json','clusters.csv','accepted_homology_edges.csv']:files.append((w/'clusters'/n,'artifacts/clusters/'+n))
 files += [(ROOT/'README.md','REPRODUCIBILITY_README.md'),(ROOT/'REPRODUCE.md','REPRODUCE.md'),(ROOT/'requirements-corrected.lock.txt','requirements-corrected.lock.txt')]
 z=DURABLE/'BS6204_Final_Results.zip';archive(z,files);publish(z)
 with open(DURABLE/'export.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);m=json.load(open(MANIFEST));r=json.load(open(REGISTRY));assert sum(bool(x.get('verified') and x.get('persisted')) for x in m['jobs'].values())>=60;m['status']='all_requested_experiments_and_deliverables_complete_verified';m['final_verification']=v;m['saved_record_audit']=record_audit;m['final_report_visual_qa']=qa;m['updated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();m['verified_persisted_seed_counts']={prefix:sum(bool(x.get('verified') and x.get('persisted')) for k,x in m['jobs'].items() if k.startswith(prefix+'/')) for prefix in sorted(set('/'.join(k.split('/')[:2]) for k in m['jobs']))}
  if (w/'ablations/verification.json').exists():m['structural_ablation_verification']=json.load(open(w/'ablations/verification.json'))
  json_file(m,MANIFEST);_send(MANIFEST,r)
 print('COMPLETE: final scientific report, code, results and manifest persisted',flush=True)
if __name__=='__main__':main()

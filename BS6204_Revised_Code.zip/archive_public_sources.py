"""Preserve the exact small public source archives and the MMseqs2 executable archive."""
import sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,archive,publish
from atomic_io import sha,json_file
from prepare_from_public import SOURCES
def main():
 w=BASE/'artifacts';manifest={};files=[]
 for name,(url,expected) in SOURCES.items():
  path=w/('models' if name.startswith('esm2') else 'downloads')/name;assert sha(path)==expected;manifest[name]={'source_url':url,'sha256':expected,'bytes':path.stat().st_size,'included':not name.startswith('esm2')}
  if not name.startswith('esm2'):files.append((path,'artifacts/downloads/'+name))
 path=w/'downloads/public_resource_manifest.json';json_file(manifest,path);files.append((path,'artifacts/downloads/'+path.name));files.append((w/'clusters/clustering_manifest.json','artifacts/clusters/clustering_manifest.json'))
 z=DURABLE/'BS6204_Public_Source_Resources.zip';archive(z,files);publish(z)
if __name__=='__main__':main()

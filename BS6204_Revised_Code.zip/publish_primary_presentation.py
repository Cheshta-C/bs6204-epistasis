"""Publish complete primary presentation content while secondary diagnostics finish."""
import sys,json
from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,archive,publish
def main():
 w=BASE/'artifacts';v=json.load(open(w/'verification/verification.json'));assert v['checkpoints_verified']==60 and v['evaluation_csv_byte_identical'];out=w/'primary_presentation';out.mkdir(exist_ok=True);keys=['epi_spearman','epi_auroc','epi_rmse'];labels=['Interaction Spearman','Interaction AUROC','Interaction RMSE'];palette={'M0':'#8592a3','M1':'#167d9a','M2':'#df8241'}
 by={p:pd.read_csv(w/f'evaluation/{p}/metrics_by_seed.csv') for p in ['protein','cluster']};cis={p:pd.read_csv(w/f'evaluation/{p}/paired_confidence_intervals.csv').query("aggregation=='macro_protein'") for p in by};t=by['cluster'].query("aggregation=='macro_protein'");means=t.groupby('model')[keys].mean();means.to_csv(out/'cluster_macro_chart_source.csv');t.to_csv(out/'cluster_individual_seeds.csv',index=False)
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'});fig,axs=plt.subplots(1,3,figsize=(10.7,3.5))
 for ax,k,label in zip(axs,keys,labels):
  for i,model in enumerate(['M0','M1','M2']):
   y=means.loc[model,k]
   if model=='M0':
    if np.isfinite(y):ax.plot(i,y,'o',color=palette[model],ms=7)
    else:ax.text(i,.05,'undefined',rotation=90,ha='center',va='bottom',transform=ax.get_xaxis_transform(),color=palette[model])
   else:
    r=cis['cluster'][cis['cluster'].metric==k].iloc[0];ax.vlines(i,r[model+'_ci_low'],r[model+'_ci_high'],color=palette[model],lw=1.8);ax.plot(i,y,'o',color=palette[model],ms=7)
  ax.set(title=label,xticks=[0,1,2],xticklabels=['M0','M1','M2'],xlim=(-.4,2.4));ax.grid(axis='y',alpha=.2)
 fig.suptitle('Cluster-disjoint nested validation | 45 proteins / 39 similarity components',fontweight='bold');fig.text(.5,.005,'Points: mean seed metrics. M1/M2 intervals resample whole similarity components, conditional on saved fits.',ha='center',fontsize=8);fig.tight_layout(rect=(0,.05,1,.94))
 for ext in ['svg','png']:fig.savefig(out/f'cluster_performance.{ext}',dpi=220,bbox_inches='tight')
 plt.close(fig);fig,axs=plt.subplots(1,3,figsize=(10.7,3.4))
 for ax,k,label in zip(axs,keys,labels):
  for i,p in enumerate(['protein','cluster']):
   r=cis[p][cis[p].metric==k].iloc[0];ax.hlines(i,r.ci_low,r.ci_high,color=['#167d9a','#df8241'][i],lw=2);ax.plot(r.M2_minus_M1,i,'o',color=['#167d9a','#df8241'][i])
  ax.axvline(0,color='#888',lw=1);ax.set(title=label,yticks=[0,1],yticklabels=['Protein','Cluster'],xlabel='M2 minus M1');ax.invert_yaxis()
 fig.suptitle('Paired whole-group bootstrap | 95% conditional intervals',fontweight='bold');fig.tight_layout()
 for ext in ['svg','png']:fig.savefig(out/f'both_protocols_paired_differences.{ext}',dpi=220,bbox_inches='tight')
 plt.close(fig);pd.concat([c.assign(protocol=p) for p,c in cis.items()]).to_csv(out/'both_protocols_CI_chart_source.csv',index=False)
 header='| Model | Interaction Spearman | Interaction AUROC | Interaction RMSE |\n|---|---:|---:|---:|\n';table=header+'\n'.join('| '+m+' | '+' | '.join(f'{means.loc[m,k]:.6f}' if pd.notna(means.loc[m,k]) else 'undefined' for k in keys)+' |' for m in ['M0','M1','M2']);intervals='\n'.join('- '+label+f": M2 minus M1 = {cis['cluster'].query('metric==@k').iloc[0].M2_minus_M1:.6f}; 95% CI [{cis['cluster'].query('metric==@k').iloc[0].ci_low:.6f}, {cis['cluster'].query('metric==@k').iloc[0].ci_high:.6f}]." for k,label in zip(keys,labels))
 old=(w/'protein_presentation/BS6204_Protein_Presentation_Content.md').read_text();a=old.index('## 7.');b=old.index('## 8.',a);section='## 7. Sequence-cluster robustness\n\n**Content**\n\n- Separate five-outer / three-inner nested validation, grouped by 39 MMseqs2 similarity components.\n- Same original 221,340 pairs / 47 assays / 45 proteins and three final seeds.\n- Whole components stay together in both levels.\n\n'+table+'\n\n'+intervals+'\n\n**Suggested visual:** cluster_performance.svg and both_protocols_paired_differences.svg; accompanying CSVs contain exact chart values.\n\n**Main takeaway:** M2 has a slightly higher interaction Spearman point estimate; none of the primary paired intervals establish a difference.\n\n**Speaker explanation:** These are separately trained cluster-disjoint models, not predictions from the protein-grouped fit. The similarity rule reduces detected homolog overlap but cannot exclude remote homology. Protocol comparisons also change fold composition. Differences use full precision, so rounding can change the last displayed digit.\n\n';text=old[:a]+section+old[b:];text=text.replace('Complete verified protein-holdout presentation content. The separate cluster experiments remain in progress.','Complete verified protein- and sequence-cluster-holdout presentation content. Secondary structure-channel diagnostics are in progress; no unverified diagnostic score is included.');text=text.replace('Structural channel-removal ablations have no reported scores until trained and verified.','Structure-channel diagnostics remain in progress in this snapshot; use the final report for their verified results.');(out/'BS6204_Presentation_Content.md').write_text(text)
 files=[(p,p.name) for p in out.iterdir() if p.is_file()];files += [(p,p.name) for p in (w/'protein_presentation').iterdir() if p.is_file() and p.suffix in ['.png','.svg','.csv']];files += [(p,'verified_metrics/'+str(p.relative_to(w/'evaluation'))) for p in (w/'evaluation').rglob('*') if p.is_file()];files += [(w/'verification/verification.json','all_60_checkpoint_verification.json'),(w/'verification/checkpoint_replay.csv','all_60_checkpoint_replay.csv'),(Path(__file__),Path(__file__).name)];archive(DURABLE/'BS6204_Presentation_Content.zip',files);publish(DURABLE/'BS6204_Presentation_Content.zip')
if __name__=='__main__':main()

"""Use the unchanged current upload helper with a longer transport read timeout."""
import sys,time
from library_hosted_apps import HostedAppsClient
from library_upload import main
# No request/payload, transfer, finalization or conflict behavior is changed.
# The default 90-second RPC read timeout is too short for large workspace archives.
HostedAppsClient._request_timeout=staticmethod(lambda deadline:300 if deadline is None else max(.001,min(300,deadline-time.monotonic())))
raise SystemExit(main(sys.argv[1:]))

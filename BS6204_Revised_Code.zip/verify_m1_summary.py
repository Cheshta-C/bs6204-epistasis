"""Separate direct recomputation from actual CSVs; no training/evaluation helper."""
import sys,json
from pathlib import Path
import pandas as pd,numpy as np
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from persistence import BASE,DURABLE,archive,publish
from atomic_io import csv_file,json_file,sha
def main():
 w=BASE/'artifacts';rows=[];hashes={};truth=pd.read_csv(w/'inputs/pairs_struct.csv').set_index(['assay','mutant']);r=w/'runs/durable_v2/protein/M1'
 for seed in [0,1,2]:
  parts=[]
  for fold in range(5):
   f=r/f'fold_{fold}/seed_{seed}/heldout_predictions.csv';hashes[str(f.relative_to(w))]=sha(f);p=pd.read_csv(f);assert (p.seed==seed).all() and (p.outer_fold==fold).all();parts.append(p)
  p=pd.concat(parts,ignore_index=True);assert len(p)==221340 and not p.duplicated(['assay','mutant']).any();assert set(map(tuple,p[['assay','mutant']].to_numpy()))==set(truth.index)
  t=truth.loc[p.set_index(['assay','mutant']).index];y=t.z_ab.to_numpy()-t.z_a.to_numpy()-t.z_b.to_numpy();assert np.allclose(y,p.true_epistasis,atol=1e-10);p['_independent_truth']=y
  values=[]
  for protein,g in p.groupby('UniProt_ID'):
   y=g._independent_truth.to_numpy();q=g.pred_epistasis.to_numpy();values.append([spearmanr(y,q).statistic,roc_auc_score(abs(y)>1,abs(q)),np.sqrt(np.mean((y-q)**2))])
  means=np.mean(values,axis=0);rows.append(dict(seed=seed,epi_spearman=means[0],epi_auroc=means[1],epi_rmse=means[2],n_pairs=len(p),n_proteins=len(values)))
 independent=pd.DataFrame(rows);saved=pd.read_csv(w/'evaluation/protein/metrics_by_seed.csv').query("model=='M1' and aggregation=='macro_protein'").sort_values('seed');assert np.allclose(independent[['epi_spearman','epi_auroc','epi_rmse']],saved[['epi_spearman','epi_auroc','epi_rmse']],atol=1e-10,rtol=0)
 out=w/'verification';out.mkdir(exist_ok=True);csv_file(independent,out/'M1_protein_independent_summary.csv');json_file({'all_15_prediction_sha256':hashes,'actual_full_oof_per_seed':221340,'direct_scipy_sklearn_recomputation':True,'maximum_difference':float(np.max(abs(independent[['epi_spearman','epi_auroc','epi_rmse']].to_numpy()-saved[['epi_spearman','epi_auroc','epi_rmse']].to_numpy()))),'mean':independent[['epi_spearman','epi_auroc','epi_rmse']].mean().to_dict(),'seed_sd_ddof1':independent[['epi_spearman','epi_auroc','epi_rmse']].std().to_dict()},out/'M1_protein_independent_verification.json')
 z=DURABLE/'BS6204_M1_Independent_Verification.zip';archive(z,[(f,'artifacts/verification/'+f.name) for f in out.glob('M1_protein_independent*')]);publish(z);print(independent.to_string(index=False),flush=True)
if __name__=='__main__':main()

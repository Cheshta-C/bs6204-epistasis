"""Save explicit untrained-M0 predictions and verify them; no fitted baseline state."""
import sys,json
from pathlib import Path
import pandas as pd,numpy as np
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,archive,publish
from model_runtime import group_folds
from scientific_metrics import validate,summaries,per_group,json_safe
from atomic_io import csv_file,json_file,sha
def main():
 w=BASE/'artifacts';out=w/'baseline';out.mkdir(exist_ok=True);d=pd.read_csv(w/'inputs/pairs_struct.csv').merge(pd.read_csv(w/'clusters/clusters.csv'),on='UniProt_ID',how='left',validate='many_to_one')
 for p,col in [('protein','UniProt_ID'),('cluster','cluster')]:
  folder=out/p;folder.mkdir(exist_ok=True);x=d.copy();x['pair_id']=x.assay+'::'+x.mutant;x['true_epistasis']=x.z_ab-x.z_a-x.z_b;x['pred_epistasis']=0.;x['pred_z_ab']=x.z_a+x.z_b;x['outer_fold']=group_folds(x,col,5);x['seed']=0;x['seed_note']='deterministic untrained baseline; no seed uncertainty';x['model']='M0';x['protocol']=p
  csv_file(x,folder/'heldout_predictions.csv');r=pd.read_csv(folder/'heldout_predictions.csv');assert len(r)==221340 and not r.pair_id.duplicated().any();assert (r.pred_epistasis==0).all();assert np.allclose(r.pred_z_ab,r.z_a+r.z_b,atol=1e-12);g=validate(d,r)
  json_file({'model':'M0','trained':False,'fitted_parameters':{},'interaction_prediction':0,'effect_prediction':'z_a+z_b','target':'z_ab-z_a-z_b','calibration_parameters':None,'normalization':'measured-singles-only sample SD ddof=1','seed':0,'seed_note':'deterministic; not a fitted random seed','pair_table_sha256':sha(w/'inputs/pairs_struct.csv')},folder/'model_definition.json')
  json_file(json_safe(summaries(g)),folder/'metrics.json');csv_file(per_group(g,'UniProt_ID'),folder/'per_protein.csv');csv_file(per_group(g,'assay'),folder/'per_assay.csv');assert json.load(open(folder/'metrics.json'))==json_safe(summaries(g))
  json_file({'n_pairs':len(r),'reopened':True,'constant_interaction_verified':True,'reconstruction_verified':True,'metrics_recomputed':True,'files':{f.name:sha(f) for f in folder.iterdir() if f.is_file() and f.name!='verification.json'}},folder/'verification.json')
 z=DURABLE/'BS6204_M0_Baseline.zip';archive(z,[(f,'artifacts/baseline/'+str(f.relative_to(out))) for f in out.rglob('*') if f.is_file()]);publish(z)
if __name__=='__main__':main()

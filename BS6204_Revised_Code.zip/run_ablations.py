"""Execute the two pre-existing structure-channel flags after required experiments."""
import sys,os,json,time,subprocess
from pathlib import Path
import numpy as np,pandas as pd,torch
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from persistence import BASE,DURABLE,MANIFEST,check,publish,archive
from atomic_io import sha,csv_file,json_file
from nested_runner import signature,verify_seed
from model_runtime import Features,group_folds
from evaluate_results import evaluate,paired_ci
W=BASE/'artifacts';FLAGS=['no_contacts','no_distance']
def verify(flag):
 d=pd.read_csv(W/'inputs/pairs_struct.csv').merge(pd.read_csv(W/'clusters/clusters.csv'),on='UniProt_ID',how='left',validate='many_to_one');d['pair_id']=d.assay+'::'+d.mutant;d['outer_fold']=group_folds(d,'UniProt_ID',5);feats=Features(d,torch.load(W/'caches/wt_emb_650.pt',weights_only=True,map_location='cpu'),dict(np.load(W/'inputs/contacts.npz')),'M2',ablation=flag);sig=signature(W,ROOT/'configs/nested_v1.json','M2','protein',flag);m=json.load(open(MANIFEST));rows=[]
 for f in range(5):
  folder=W/f'runs/durable_v2/protein/M2_{flag}/fold_{f}';assert json.load(open(folder/'COMPLETE.json'))['signature']==sig
  for n in ['outer_assignments.csv','inner_assignments.csv']:pd.testing.assert_frame_equal(pd.read_csv(folder/n),pd.read_csv(W/f'runs/durable_v2/protein/M2/fold_{f}'/n))
  for seed in [0,1,2]:
   key=f'protein/M2_{flag}/fold_{f}/seed_{seed}';rec=m['jobs'][key];assert rec['persisted'] and rec['verified'];job=folder/f'seed_{seed}';assert all((job/n).is_file() and sha(job/n)==v for n,v in rec['files'].items());r=verify_seed(job,feats,np.flatnonzero(d.outer_fold.to_numpy()==f),sig,f,seed);rows.append(dict(ablation=flag,fold=f,seed=seed,n_test=r['n_test'],max_abs_inference_difference=r['max_abs_inference_difference'],checkpoint_sha256=sha(job/'checkpoint.pt'),passed=True))
 return rows
def run(flag,completed):
 todo=list(range(5));running={};handles={}
 while todo or running:
  check()
  while todo and len(running)<4:
   f=todo.pop(0);h=open(W/f'logs/protein-M2_{flag}-fold{f}.log','a');cmd=[sys.executable,'-u',str(ROOT/'src/nested_runner.py'),'--protocol','protein','--model','M2','--fold',str(f),'--threads','2','--ablation',flag];running[f]=subprocess.Popen(cmd,stdout=h,stderr=subprocess.STDOUT,env=os.environ.copy());handles[f]=h;print('START ABLATION',flag,f,flush=True)
  for f,p in list(running.items()):
   code=p.poll()
   if code is not None:
    running.pop(f);handles.pop(f).close();print('EXIT ABLATION',flag,f,code,flush=True)
    if code:
     for other in running.values():other.terminate()
     raise RuntimeError('Ablation failed; see log')
  if running:time.sleep(2)
 completed.append(flag);out=W/'ablations';out.mkdir(exist_ok=True);rows=[]
 for x in completed:rows.extend(verify(x))
 csv_file(pd.DataFrame(rows),out/'checkpoint_replay.csv');evaluate(W,'protein',['M2']+['M2_'+x for x in completed],out/'evaluation');tables={l:pd.read_csv(out/f'evaluation/per_{l}.csv') for l in ['protein','assay']};pairs=pd.read_csv(W/'inputs/pairs_struct.csv');clusters=pd.read_csv(W/'clusters/clusters.csv');cis=[]
 for x in completed:
  model='M2_'+x;t={l:z[z.model.isin(['M2',model])].assign(model=lambda q:q.model.map({'M2':'M1',model:'M2'})) for l,z in tables.items()};c=paired_ci(t,pairs,clusters,'protein').rename(columns={'M1':'full_M2','M2':'ablated','M2_minus_M1':'ablated_minus_full_M2','M1_ci_low':'full_ci_low','M1_ci_high':'full_ci_high','M2_ci_low':'ablated_ci_low','M2_ci_high':'ablated_ci_high'});c['ablation']=x;cis.append(c)
 csv_file(pd.concat(cis,ignore_index=True),out/'paired_channel_comparisons.csv');json_file({'completed_ablations':completed,'checkpoints_verified':len(rows),'same_pairs_and_splits_as_primary':True,'all_requested_ablations_complete':set(completed)==set(FLAGS),'conditional_group_bootstrap':True},out/'verification.json');files=[(p,'artifacts/'+str(p.relative_to(W))) for p in out.rglob('*') if p.is_file()]
 for x in completed:
  folder=W/f'runs/durable_v2/protein/M2_{x}';files += [(p,'artifacts/'+str(p.relative_to(W))) for p in folder.rglob('*') if p.is_file()]
 files.append((ROOT/'configs/structural_ablation_plan.json','structural_ablation_plan.json'));archive(DURABLE/'BS6204_Structural_Ablations.zip',files);publish(DURABLE/'BS6204_Structural_Ablations.zip')
def main():
 v=json.load(open(W/'verification/verification.json'));assert v['checkpoints_verified']==60 and v['evaluation_csv_byte_identical'] and v['all_seed_packages_persisted'];torch.set_num_threads(2);os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='2';completed=[]
 for flag in FLAGS:run(flag,completed)
 print('ALL PREDEFINED STRUCTURAL CHANNEL ABLATIONS VERIFIED AND SAVED',flush=True)
if __name__=='__main__':main()
